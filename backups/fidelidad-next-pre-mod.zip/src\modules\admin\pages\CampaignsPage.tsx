import React, { useState, useEffect } from 'react';
import { Plus, Trash2, Calendar, Target, Award, Save, X, Edit2, Megaphone, Sparkles, ToggleLeft, ToggleRight, Edit, Send } from 'lucide-react';
import toast from 'react-hot-toast';
import { CampaignService } from '../../../services/campaignService';
import { ConfigService, DEFAULT_TEMPLATES } from '../../../services/configService';
import type { BonusRule } from '../../../services/campaignService';
import type { AppConfig } from '../../../types';
import { useNavigate } from 'react-router-dom';
import { collection, getDocs, query } from 'firebase/firestore'; // Added imports
import { db } from '../../../lib/firebase'; // Added import
import { NotificationService } from '../../../services/notificationService'; // Added import

export const CampaignsPage = () => {
    const navigate = useNavigate();
    const [bonuses, setBonuses] = useState<BonusRule[]>([]);
    // const [loading, setLoading] = useState(false); // Unused

    // Modal State
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingId, setEditingId] = useState<string | null>(null); // Track if editing
    const [formData, setFormData] = useState<Partial<BonusRule>>({
        name: '',
        description: '',
        rewardType: 'FIXED',
        rewardValue: 50,
        daysOfWeek: [],
        active: true,
        startDate: '',
        endDate: '',
        imageUrl: '',
        showInApp: false,
        backgroundColor: '',
        imageFit: 'contain',
        textPosition: 'bottom-left',
        fontStyle: 'sans',
        showTitle: true
    });

    const DAYS = [
        { id: 0, label: 'Dom' },
        { id: 1, label: 'Lun' },
        { id: 2, label: 'Mar' },
        { id: 3, label: 'Mie' },
        { id: 4, label: 'Jue' },
        { id: 5, label: 'Vie' },
        { id: 6, label: 'Sab' }
    ];

    const fetchBonuses = async () => {
        // setLoading(true);
        const data = await CampaignService.getAll();
        setBonuses(data);
        // setLoading(false);
    };

    useEffect(() => {
        fetchBonuses();
    }, []);

    const resetForm = () => {
        setFormData({
            name: '', description: '', rewardType: 'FIXED', rewardValue: 50,
            daysOfWeek: [], active: true, startDate: '', endDate: '', imageUrl: '', showInApp: false,
            showTitle: true, imageFit: 'contain', textPosition: 'bottom-left', fontStyle: 'sans'
        });
        setEditingId(null);
    };

    const handleSave = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            // Validate: If INFO, ensure we have at least image or description
            if (formData.rewardType === 'INFO' && !formData.imageUrl && !formData.description) {
                toast.error('Un anuncio debe tener imagen o descripción');
                return;
            }

            const payload = {
                ...formData,
                // Ensure rewardValue is 0 if INFO, to avoid confusion
                rewardValue: formData.rewardType === 'INFO' ? 0 : formData.rewardValue
            };

            if (editingId) {
                await CampaignService.update(editingId, payload);
                toast.success('Campaña actualizada');
            } else {
                // @ts-ignore
                await CampaignService.create(payload);
                toast.success('Campaña creada');
            }
            setIsModalOpen(false);
            fetchBonuses();
            resetForm();
        } catch (error) {
            toast.error('Error al guardar campaña');
        }
    };

    const handleEdit = (bonus: BonusRule) => {
        setEditingId(bonus.id);
        setFormData({
            ...bonus,
            description: bonus.description || '',
            startDate: bonus.startDate || '',
            endDate: bonus.endDate || '',
            imageUrl: bonus.imageUrl || '',
            showInApp: bonus.showInApp || false,
            backgroundColor: bonus.backgroundColor || '',
            imageFit: bonus.imageFit || 'contain',
            textPosition: bonus.textPosition || 'bottom-left',
            fontStyle: bonus.fontStyle || 'sans',
            showTitle: bonus.showTitle !== false
        });
        setIsModalOpen(true);
    };

    const handleToggleActive = async (bonus: BonusRule) => {
        try {
            const newStatus = !bonus.active;
            setBonuses(bonuses.map(b => b.id === bonus.id ? { ...b, active: newStatus } : b));
            await CampaignService.update(bonus.id, { active: newStatus });
            toast.success(`Campaña ${newStatus ? 'activada' : 'desactivada'}`);
        } catch (error) {
            toast.error('Error al actualizar');
            fetchBonuses();
        }
    };

    const handleDelete = async (id: string) => {
        if (!confirm('¿Eliminar esta campaña permanentemente?')) return;
        try {
            await CampaignService.delete(id);
            toast.success('Campaña eliminada');
            fetchBonuses();
        } catch (error) {
            toast.error('Error al eliminar');
        }
    };

    const handleBroadcast = async (bonus: BonusRule) => {
        try {
            const config = await ConfigService.get();
            const eventType = bonus.rewardType === 'INFO' ? 'offer' : 'campaign';

            // 1. Prepare Message
            let template = "";
            let msg = "";

            if (bonus.rewardType === 'INFO') {
                template = config?.messaging?.templates?.offer || DEFAULT_TEMPLATES.offer;
                const vencimiento = bonus.endDate
                    ? new Date(bonus.endDate + 'T00:00:00').toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit' })
                    : 'agotar stock';
                msg = template
                    .replace(/{titulo}/g, bonus.name)
                    .replace(/{detalle}/g, bonus.description || 'Consultanos.')
                    .replace(/{vencimiento}/g, vencimiento);
            } else {
                template = config?.messaging?.templates?.campaign || DEFAULT_TEMPLATES.campaign;
                msg = template
                    .replace(/{nombre}/g, bonus.name)
                    .replace(/{descripcion}/g, bonus.description || '¡Sumá más puntos!');
            }

            // 2. CHECK PUSH ENABLEMENT & SEND
            if (NotificationService.isChannelEnabled(config, eventType, 'push')) {
                const confirmPush = confirm(`¿Enviar notificación PUSH a todos los clientes activos?\n\n"${msg}"`);
                if (confirmPush) {
                    const loadingToast = toast.loading('Enviando Pushes...');
                    try {
                        // 1. Fetch active users to send notifications
                        // In a real app with thousands, use a Cloud Function.
                        const q = query(collection(db, 'users')); // Reverted to 'users'
                        const snap = await getDocs(q);

                        let sentCount = 0;
                        const pushPromises = snap.docs.map(doc => {
                            // const data = doc.data(); // Unused
                            // Basic filter: check if valid user (optional)
                            sentCount++;
                            return NotificationService.sendToClient(doc.id, {
                                title: bonus.rewardType === 'INFO' ? '¡Nueva Oferta!' : '¡Nueva Campaña!',
                                body: msg,
                                type: eventType,
                                // Optional: Link deeping
                            });
                        });

                        await Promise.allSettled(pushPromises);
                        toast.success(`Push enviado a ${sentCount} clientes`, { id: loadingToast });
                    } catch (err) {
                        console.error("Push Broadcast Error", err);
                        toast.error("Error enviando Pushes", { id: loadingToast });
                    }
                }
            }

            // 3. CHECK WHATSAPP ENABLEMENT & REDIRECT
            // Note: Granular check for WhatsApp too, or fallback to global?
            // Existing logic relied on global. We now use granular if available.
            const waEnabled = NotificationService.isChannelEnabled(config, eventType, 'whatsapp');

            if (waEnabled) {
                navigate('/admin/whatsapp', { state: { message: msg } });
                toast.success('Redirigiendo a Mensajería WhatsApp...');
            } else if (!NotificationService.isChannelEnabled(config, eventType, 'push')) {
                toast('Ningún canal (WhatsApp/Push) habilitado para este evento.', { icon: 'ℹ️' });
            }

        } catch (error) {
            console.error(error);
            toast.error('Error al preparar difusión');
        }
    };

    const toggleDay = (dayId: number) => {
        setFormData(prev => {
            const currentDays = prev.daysOfWeek || [];
            const exists = currentDays.includes(dayId);
            if (exists) return { ...prev, daysOfWeek: currentDays.filter(d => d !== dayId) };
            return { ...prev, daysOfWeek: [...currentDays, dayId].sort() };
        });
    };

    return (
        <div className="space-y-8 animate-fade-in pb-20">
            {/* Header */}
            <div className="flex justify-between items-center border-b border-gray-100 pb-6">
                <div>
                    <h1 className="text-3xl font-bold text-gray-800 flex items-center gap-2">
                        <Target className="text-purple-600" /> Campañas y Anuncios
                    </h1>
                    <p className="text-gray-500 mt-1">Configura reglas de puntos, bonos y banners publicitarios.</p>
                </div>
                <button
                    onClick={() => { resetForm(); setIsModalOpen(true); }}
                    className="bg-purple-600 hover:bg-purple-700 text-white px-5 py-2.5 rounded-xl font-bold shadow-lg shadow-purple-200 transition flex items-center gap-2 active:scale-95"
                >
                    <Plus size={20} /> Crear Nuevo
                </button>
            </div>

            {/* Grid de Bonos */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {bonuses.map(bonus => (
                    <div key={bonus.id} className={`bg-white rounded-2xl border-2 transition-all relative overflow-hidden group flex flex-col ${bonus.active ? 'border-purple-100 shadow-sm hover:shadow-md' : 'border-gray-100 opacity-60 grayscale-[0.8] hover:grayscale-0'}`}>

                        {/* Banner Image Preview */}
                        <div className="h-32 bg-gray-100 relative overflow-hidden">
                            {bonus.imageUrl ? (
                                <img src={bonus.imageUrl} alt={bonus.name} className="w-full h-full object-cover" />
                            ) : (
                                <div className="w-full h-full flex items-center justify-center text-gray-300">
                                    {bonus.rewardType === 'INFO' ? <Megaphone size={32} /> : <Sparkles size={32} />}
                                </div>
                            )}

                            {/* App Visibility Badge */}
                            {bonus.showInApp && (
                                <div className="absolute top-2 left-2 bg-black/60 backdrop-blur-sm text-white text-[10px] font-bold px-2 py-1 rounded-full flex items-center gap-1">
                                    <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"></span>
                                    Visible en App
                                </div>
                            )}

                            {/* Status Toggle */}
                            <div className="absolute top-2 right-2">
                                <button
                                    onClick={() => handleToggleActive(bonus)}
                                    className={`bg-white/90 backdrop-blur rounded-full p-1 transition-colors shadow-sm ${bonus.active ? 'text-green-500' : 'text-gray-400'}`}
                                    title={bonus.active ? 'Desactivar' : 'Activar'}
                                >
                                    {bonus.active ? <ToggleRight size={28} className="fill-current" /> : <ToggleLeft size={28} />}
                                </button>
                            </div>
                        </div>

                        <div className="p-5 flex-1 flex flex-col">
                            <div className="flex items-start justify-between mb-2">
                                <div>
                                    <h3 className="font-bold text-gray-800 text-lg leading-tight line-clamp-1">{bonus.name}</h3>
                                    <p className="text-xs text-gray-500 line-clamp-2 mt-1 min-h-[2.5em]">{bonus.description || 'Sin descripción'}</p>
                                </div>
                            </div>

                            <div className={`font-bold text-sm px-3 py-1.5 rounded-lg inline-flex items-center gap-2 w-fit mb-4 ${bonus.rewardType === 'INFO'
                                ? 'text-blue-600 bg-blue-50'
                                : 'text-purple-600 bg-purple-50'
                                }`}>
                                {bonus.rewardType === 'INFO' ? (
                                    <>
                                        <Megaphone size={14} /> Solo Anuncio
                                    </>
                                ) : (
                                    <>
                                        <Sparkles size={14} />
                                        {bonus.rewardType === 'MULTIPLIER' ? `Multiplica x${bonus.rewardValue}` : `+${bonus.rewardValue} Puntos`}
                                    </>
                                )}
                            </div>

                            <div className="mt-auto space-y-3">
                                {/* Date Range */}
                                {(bonus.startDate || bonus.endDate) && (
                                    <div className="text-[11px] font-medium text-gray-500 bg-gray-50 px-2 py-1 rounded border border-gray-100 flex items-center">
                                        📅 {bonus.startDate || 'Inicio'} - {bonus.endDate || 'Fin'}
                                    </div>
                                )}

                                {/* Days */}
                                <div className="flex flex-wrap gap-1">
                                    {DAYS.map(day => (
                                        <span
                                            key={day.id}
                                            className={`text-[9px] uppercase font-bold px-1.5 py-0.5 rounded ${bonus.daysOfWeek?.includes(day.id) ? 'bg-purple-100 text-purple-700' : 'bg-gray-50 text-gray-300'}`}
                                        >
                                            {day.label.slice(0, 1)}
                                        </span>
                                    ))}
                                </div>
                            </div>
                        </div>

                        {/* Footer Actions */}
                        <div className="px-5 py-3 border-t border-gray-50 flex justify-between items-center bg-gray-50/30">
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${bonus.active ? 'bg-green-100 text-green-700' : 'bg-gray-200 text-gray-500'}`}>
                                {bonus.active ? 'ACTIVO' : 'PAUSADO'}
                            </span>

                            <div className="flex gap-2">
                                <button
                                    onClick={() => handleBroadcast(bonus)}
                                    className="text-gray-400 hover:text-green-600 transition p-1.5 hover:bg-green-50 rounded-lg flex items-center gap-1"
                                    title="Difundir por WhatsApp"
                                >
                                    <Send size={16} />
                                    <span className="text-xs font-bold">Difundir</span>
                                </button>
                                <div className="w-px h-4 bg-gray-200 self-center mx-1"></div>
                                <button
                                    onClick={() => handleEdit(bonus)}
                                    className="text-gray-400 hover:text-blue-500 transition p-1.5 hover:bg-blue-50 rounded-lg"
                                    title="Editar"
                                >
                                    <Edit size={16} />
                                </button>
                                <button
                                    onClick={() => handleDelete(bonus.id)}
                                    className="text-gray-400 hover:text-red-500 transition p-1.5 hover:bg-red-50 rounded-lg"
                                    title="Eliminar"
                                >
                                    <Trash2 size={16} />
                                </button>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {/* Modal de Creación / Edición */}
            {isModalOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-fade-in overflow-y-auto">
                    <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden animate-scale-up my-8">
                        <div className="px-6 py-4 bg-purple-50 border-b border-purple-100 flex justify-between items-center sticky top-0 z-10">
                            <h2 className="text-lg font-bold text-purple-900">
                                {editingId ? 'Editar Elemento' : 'Nuevo Elemento'}
                            </h2>
                            <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600 rounded-full p-1"><X size={20} /></button>
                        </div>

                        <form onSubmit={handleSave} className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">

                            {/* Columna Izquierda: Datos Básicos */}
                            <div className="space-y-4">
                                <h3 className="font-bold text-gray-800 border-b pb-2 mb-2 text-sm">Configuración Principal</h3>

                                <div>
                                    <label className="block text-xs font-bold text-gray-500 mb-1">Nombre Interno</label>
                                    <input
                                        type="text" required
                                        placeholder="Ej: Banner Navidad"
                                        className="w-full rounded-lg border-gray-200 border p-2 text-sm outline-none focus:ring-2 focus:ring-purple-100"
                                        value={formData.name}
                                        onChange={e => setFormData({ ...formData, name: e.target.value })}
                                    />
                                </div>

                                <div>
                                    <label className="block text-xs font-bold text-gray-500 mb-1">¿Qué tipo de elemento es?</label>
                                    <select
                                        className="w-full rounded-lg border-gray-200 border p-2.5 text-sm font-semibold outline-none focus:ring-2 focus:ring-purple-100 bg-white"
                                        value={formData.rewardType}
                                        onChange={e => setFormData({ ...formData, rewardType: e.target.value as any })}
                                    >
                                        <option value="FIXED">🎁 Bono de Puntos Fijos (+)</option>
                                        <option value="MULTIPLIER">🚀 Bono Multiplicador (x)</option>
                                        <option value="INFO">📢 Solo Anuncio / Banner</option>
                                    </select>
                                </div>

                                {formData.rewardType !== 'INFO' && (
                                    <div className="animate-fade-in-down">
                                        <label className="block text-xs font-bold text-gray-500 mb-1">Valor</label>
                                        <input
                                            type="number" required min="1" step={formData.rewardType === 'MULTIPLIER' ? "0.1" : "1"}
                                            className="w-full rounded-lg border-gray-200 border p-2 text-sm font-bold text-purple-600 outline-none focus:ring-2 focus:ring-purple-100"
                                            value={formData.rewardValue}
                                            onChange={e => setFormData({ ...formData, rewardValue: parseFloat(e.target.value) || 0 })}
                                        />
                                    </div>
                                )}

                                <div>
                                    <label className="block text-xs font-bold text-gray-500 mb-1">Días de Aplicación</label>
                                    <div className="flex flex-wrap gap-1.5">
                                        {DAYS.map(day => (
                                            <button
                                                key={day.id}
                                                type="button"
                                                onClick={() => toggleDay(day.id)}
                                                className={`w-8 h-8 rounded text-[10px] font-bold transition border ${formData.daysOfWeek?.includes(day.id)
                                                    ? 'bg-purple-600 text-white border-purple-600'
                                                    : 'bg-white text-gray-400 border-gray-200 hover:border-gray-300'
                                                    }`}
                                            >
                                                {day.label.slice(0, 2)}
                                            </button>
                                        ))}
                                    </div>
                                    <p className="text-[10px] text-gray-400 mt-1">Si es anuncio, se mostrará estos días.</p>
                                </div>

                                {formData.rewardType !== 'INFO' && (
                                    <div className="p-3 bg-gray-50 rounded-lg text-xs text-gray-500 border border-gray-100 animate-fade-in">
                                        {formData.rewardType === 'FIXED'
                                            ? `Se sumarán +${formData.rewardValue} puntos extra en cada compra.`
                                            : `Los puntos de la compra se multiplicarán por ${formData.rewardValue}.`}
                                    </div>
                                )}
                            </div>

                            {/* Columna Derecha: Datos App */}
                            <div className="space-y-4">
                                <h3 className="font-bold text-gray-800 border-b pb-2 mb-2 text-sm">Visualización en App (PWA)</h3>

                                {/* LIVE PREVIEW COMPONENT */}
                                <div className="bg-gray-100 p-4 rounded-xl mb-4 border border-gray-200">
                                    <label className="block text-xs font-bold text-gray-400 mb-2 uppercase tracking-wider text-center">Vista Previa en Vivo</label>
                                    <div className="relative overflow-hidden rounded-2xl shadow-xl shadow-gray-200/50 h-48 w-full max-w-sm mx-auto transition-all duration-500">
                                        {(() => {
                                            const hasImg = !!formData.imageUrl;
                                            const gradients = [
                                                'bg-gradient-to-br from-pink-500 to-rose-500',
                                                'bg-gradient-to-br from-purple-600 to-indigo-600',
                                                'bg-gradient-to-br from-blue-400 to-cyan-500',
                                                'bg-gradient-to-br from-orange-400 to-red-500'
                                            ];
                                            const gradientBg = gradients[1];
                                            const customStyle = formData.backgroundColor ? { backgroundColor: formData.backgroundColor } : {};
                                            const bgClass = formData.backgroundColor ? '' : (hasImg ? 'bg-gray-900' : gradientBg);

                                            // Estilos dinámicos
                                            const imgFitClass = formData.imageFit === 'cover' ? 'object-cover' : 'object-contain';
                                            const fontClass = formData.fontStyle === 'serif' ? 'font-serif' : formData.fontStyle === 'mono' ? 'font-mono' : 'font-sans';

                                            // Posición del Texto
                                            let textPosClass = 'items-end justify-start'; // Default: bottom-left
                                            if (formData.textPosition === 'bottom-center') textPosClass = 'items-end justify-center text-center';
                                            if (formData.textPosition === 'bottom-right') textPosClass = 'items-end justify-end text-right';
                                            if (formData.textPosition === 'center') textPosClass = 'items-center justify-center text-center';
                                            if (formData.textPosition === 'top-left') textPosClass = 'items-start justify-start';
                                            if (formData.textPosition === 'top-center') textPosClass = 'items-start justify-center text-center';
                                            if (formData.textPosition === 'top-right') textPosClass = 'items-start justify-end text-right';

                                            return (
                                                <div
                                                    className={`w-full h-full relative flex ${textPosClass} ${bgClass}`}
                                                    style={customStyle}
                                                >
                                                    {hasImg ? (
                                                        <>
                                                            <img
                                                                src={formData.imageUrl}
                                                                alt={formData.name}
                                                                className={`absolute inset-0 w-full h-full ${imgFitClass} opacity-90`}
                                                                onError={(e) => (e.currentTarget.style.display = 'none')}
                                                            />
                                                            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                                                        </>
                                                    ) : (
                                                        <>
                                                            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-3xl -mr-10 -mt-10"></div>
                                                            <div className="absolute bottom-0 left-0 w-24 h-24 bg-black/10 rounded-full blur-2xl -ml-5 -mb-5"></div>
                                                        </>
                                                    )}

                                                    {/* CONTENT */}
                                                    {/* CONTENT */}
                                                    <div className={`relative z-10 p-5 text-white ${fontClass} w-full`}>
                                                        {formData.showTitle !== false && (
                                                            <h3 className={`font-bold leading-tight drop-shadow-sm ${hasImg ? 'text-lg' : 'text-xl mb-1'}`}>
                                                                {formData.name || 'Título'}
                                                            </h3>
                                                        )}
                                                        {(formData.description || !hasImg) && (
                                                            <p className={`opacity-90 leading-snug line-clamp-2 ${hasImg ? 'text-[11px] text-gray-100 mt-1' : 'text-xs font-medium text-white/90 mt-2'}`}>
                                                                {formData.description || 'Descripción...'}
                                                            </p>
                                                        )}
                                                    </div>
                                                </div>
                                            );
                                        })()}
                                    </div>
                                    <p className="text-[10px] text-gray-400 text-center mt-2">Así lo verán tus clientes.</p>
                                </div>

                                <div className="grid grid-cols-2 gap-3">
                                    <div>
                                        <label className="block text-xs font-bold text-gray-500 mb-1">Ajuste de Imagen</label>
                                        <select
                                            className="w-full rounded-lg border-gray-200 border p-2 text-sm"
                                            value={formData.imageFit || 'contain'}
                                            onChange={e => setFormData({ ...formData, imageFit: e.target.value as any })}
                                        >
                                            <option value="contain">Completa (Contain)</option>
                                            <option value="cover">Llenar Banner (Cover)</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold text-gray-500 mb-1">Tipografía</label>
                                        <select
                                            className="w-full rounded-lg border-gray-200 border p-2 text-sm"
                                            value={formData.fontStyle || 'sans'}
                                            onChange={e => setFormData({ ...formData, fontStyle: e.target.value as any })}
                                        >
                                            <option value="sans">Moderna (Sans)</option>
                                            <option value="serif">Elegante (Serif)</option>
                                            <option value="mono">Máquina (Mono)</option>
                                        </select>
                                    </div>
                                </div>

                                <div>
                                    <label className="block text-xs font-bold text-gray-500 mb-1">Posición del Texto</label>
                                    <div className="grid grid-cols-5 gap-1 bg-gray-50 p-1 rounded-lg border border-gray-200">
                                        {[
                                            { id: 'top-left', label: '↖' }, { id: 'top-center', label: '↑' }, { id: 'top-right', label: '↗' },
                                            { id: 'center', label: '•' },
                                            { id: 'bottom-left', label: '↙' }, { id: 'bottom-center', label: '↓' }, { id: 'bottom-right', label: '↘' }
                                        ].filter((_, i) => i < 7).map(pos => (
                                            <button
                                                key={pos.id}
                                                type="button"
                                                onClick={() => setFormData({ ...formData, textPosition: pos.id as any })}
                                                className={`h-8 rounded text-lg flex items-center justify-center transition ${(formData.textPosition || 'bottom-left') === pos.id
                                                    ? 'bg-purple-600 text-white shadow-sm'
                                                    : 'text-gray-400 hover:bg-white hover:text-gray-600'
                                                    }`}
                                                title={pos.id.replace('-', ' ')}
                                            >
                                                {pos.label}
                                            </button>
                                        ))}
                                    </div>
                                </div>

                                <div className="flex gap-4">
                                    <label className="flex items-center gap-2 cursor-pointer mb-2">
                                        <input
                                            type="checkbox"
                                            className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
                                            checked={formData.showInApp}
                                            onChange={e => setFormData({ ...formData, showInApp: e.target.checked })}
                                        />
                                        <span className="text-sm font-bold text-gray-700">Mostrar Banner en App</span>
                                    </label>

                                    <label className="flex items-center gap-2 cursor-pointer mb-2">
                                        <input
                                            type="checkbox"
                                            className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
                                            checked={formData.showTitle !== false}
                                            onChange={e => setFormData({ ...formData, showTitle: e.target.checked })}
                                        />
                                        <span className="text-sm font-bold text-gray-700">Mostrar Título</span>
                                    </label>
                                </div>

                                <div>
                                    <label className="block text-xs font-bold text-gray-500 mb-1">Descripción Pública</label>
                                    <textarea
                                        className="w-full rounded-lg border-gray-200 border p-2 text-sm outline-none focus:ring-2 focus:ring-purple-100 h-20 resize-none"
                                        placeholder={formData.rewardType === 'INFO' ? "Ej: ¡Llegaron los nuevos productos!" : "Ej: ¡Sumá puntos doble hoy!"}
                                        value={formData.description}
                                        onChange={e => setFormData({ ...formData, description: e.target.value })}
                                        disabled={!formData.showInApp}
                                    />
                                </div>

                                <div>
                                    <label className="block text-xs font-bold text-gray-500 mb-1">URL de Imagen {formData.rewardType === 'INFO' && <span className="text-red-500">*</span>}</label>
                                    <input
                                        type="url"
                                        placeholder="https://imgur.com/example.jpg"
                                        className="w-full rounded-lg border-gray-200 border p-2 text-sm outline-none focus:ring-2 focus:ring-purple-100"
                                        value={formData.imageUrl}
                                        onChange={e => setFormData({ ...formData, imageUrl: e.target.value })}
                                        disabled={!formData.showInApp}
                                    />
                                    <p className="text-[10px] text-gray-400 mt-1">Recomendado: 800x600px o formato cuadrado (se ajusta automáticamente)</p>
                                </div>

                                <div>
                                    <label className="block text-xs font-bold text-gray-500 mb-1">Color de Fondo</label>
                                    <div className="flex items-center gap-2">
                                        <input
                                            type="color"
                                            className="h-10 w-10 rounded-lg cursor-pointer border-0 p-0 shadow-sm"
                                            value={formData.backgroundColor || '#4F46E5'}
                                            onChange={e => setFormData({ ...formData, backgroundColor: e.target.value })}
                                            disabled={!formData.showInApp}
                                        />
                                        <input
                                            type="text"
                                            className="flex-1 rounded-lg border-gray-200 border p-2 text-sm uppercase"
                                            placeholder="#4F46E5"
                                            value={formData.backgroundColor || ''}
                                            onChange={e => setFormData({ ...formData, backgroundColor: e.target.value })}
                                            disabled={!formData.showInApp}
                                        />
                                    </div>
                                    <p className="text-[10px] text-gray-400 mt-1">Se usará si no hay imagen o como fondo del texto.</p>
                                </div>

                                <div className="grid grid-cols-2 gap-3">
                                    <div>
                                        <label className="block text-xs font-bold text-gray-500 mb-1">Fecha Inicio</label>
                                        <input
                                            type="date"
                                            className="w-full rounded-lg border-gray-200 border p-2 text-sm"
                                            value={formData.startDate}
                                            onChange={e => setFormData({ ...formData, startDate: e.target.value })}
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold text-gray-500 mb-1">Fecha Fin</label>
                                        <input
                                            type="date"
                                            className="w-full rounded-lg border-gray-200 border p-2 text-sm"
                                            value={formData.endDate}
                                            onChange={e => setFormData({ ...formData, endDate: e.target.value })}
                                        />
                                    </div>
                                </div>
                            </div>

                            <div className="col-span-full pt-4 border-t border-gray-50 flex gap-3">
                                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 py-3 text-gray-500 font-medium hover:bg-gray-100 rounded-xl transition">Cancelar</button>
                                <button type="submit" className="flex-1 py-3 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl shadow-lg transition active:scale-95 flex items-center justify-center gap-2">
                                    <Save size={18} /> {editingId ? 'Actualizar' : 'Guardar'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};
