import { useState, useEffect } from 'react';
import { collection, getDocs, query, where, collectionGroup, orderBy, limit, doc, getDoc } from 'firebase/firestore';
import { db } from '../../../lib/firebase';
import { ArrowUpRight, ArrowDownLeft, TrendingUp, Gift, User, Clock } from 'lucide-react';

export const DashboardPage = () => {
    const [stats, setStats] = useState({
        usersCount: 0,
        totalPoints: 0,
        redeemedPoints: 0,
        redeemedMoney: 0
    });
    const [recentActivity, setRecentActivity] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchStats = async () => {
            try {
                // 1. KPI Stats
                // Clientes
                const qUsers = query(collection(db, 'users'), where('role', '==', 'client')); // Reverted to 'users'
                const snapUsers = await getDocs(qUsers);

                let points = 0;
                snapUsers.forEach(doc => {
                    const d = doc.data();
                    points += ((d.points || d.puntos) || 0);
                });

                // Canjes Globales
                const qRedeems = query(collectionGroup(db, 'points_history'), where('type', '==', 'debit'));
                const snapRedeems = await getDocs(qRedeems);

                let redeemedPoints = 0;
                let redeemedMoney = 0;
                snapRedeems.forEach(doc => {
                    const data = doc.data();
                    redeemedPoints += Math.abs(data.amount || 0);
                    redeemedMoney += (data.redeemedValue || 0);
                });

                setStats({
                    usersCount: snapUsers.size,
                    totalPoints: points,
                    redeemedPoints,
                    redeemedMoney
                });

                // 2. Recent Activity Feed
                const qActivity = query(
                    collectionGroup(db, 'points_history'),
                    orderBy('date', 'desc'),
                    limit(10)
                );
                const snapActivity = await getDocs(qActivity);

                // Helper to fetch user names
                const userCache = new Map();
                const getUserName = async (uid: string) => {
                    if (userCache.has(uid)) return userCache.get(uid);
                    try {
                        const userDoc = await getDoc(doc(db, 'users', uid)); // Reverted to 'users'
                        const d = userDoc.exists() ? userDoc.data() : null;
                        const name = d ? (d.name || d.nombre || 'Usuario Desconocido') : 'Usuario Desconocido';
                        userCache.set(uid, name);
                        return name;
                    } catch (e) {
                        return 'Usuario';
                    }
                };

                const activities = await Promise.all(snapActivity.docs.map(async (d) => {
                    const data = d.data();
                    const userId = d.ref.parent.parent?.id; // users/{id}/points_history/{doc}
                    const userName = userId ? await getUserName(userId) : 'Sistema';

                    return {
                        id: d.id,
                        ...data,
                        date: data.date?.toDate ? data.date.toDate() : new Date(),
                        userName
                    };
                }));

                setRecentActivity(activities);

            } catch (error) {
                console.error("Error fetching dashboard data:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchStats();
    }, []);

    // Helper formatter
    const formatTime = (date: Date) => {
        const now = new Date();
        const diffMins = Math.floor((now.getTime() - date.getTime()) / 60000);

        if (diffMins < 1) return 'Ahora';
        if (diffMins < 60) return `${diffMins} min`;
        const diffHours = Math.floor(diffMins / 60);
        if (diffHours < 24) return `${diffHours} h`;
        return date.toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit', year: '2-digit' });
    };

    return (
        <div className="animate-fade-in pb-10">
            <h1 className="text-2xl font-bold text-gray-800 mb-6">Tablero Principal</h1>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                {/* KPI Cards */}
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between transition hover:shadow-md">
                    <div>
                        <h3 className="text-gray-500 text-sm font-medium mb-1">Usuarios Activos</h3>
                        <p className="text-3xl font-bold text-gray-900">
                            {loading ? '...' : stats.usersCount}
                        </p>
                    </div>
                    <div className="bg-blue-50 p-3 rounded-xl text-blue-600">
                        <User size={24} />
                    </div>
                </div>

                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between transition hover:shadow-md">
                    <div>
                        <h3 className="text-gray-500 text-sm font-medium mb-1">Puntos en Circulación</h3>
                        <p className="text-3xl font-bold text-indigo-600">
                            {loading ? '...' : stats.totalPoints.toLocaleString()}
                        </p>
                    </div>
                    <div className="bg-indigo-50 p-3 rounded-xl text-indigo-600">
                        <TrendingUp size={24} />
                    </div>
                </div>

                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between transition hover:shadow-md">
                    <div>
                        <h3 className="text-gray-500 text-sm font-medium mb-1">Total Canjeado</h3>
                        <div className="flex flex-col">
                            <p className="text-3xl font-bold text-orange-500">
                                {loading ? '...' : stats.redeemedPoints.toLocaleString()}
                            </p>
                            <span className="text-xs font-semibold text-green-600 bg-green-50 px-2 py-0.5 rounded-full mt-1 w-fit">
                                ≈ ${stats.redeemedMoney.toLocaleString()}
                            </span>
                        </div>
                    </div>
                    <div className="bg-orange-50 p-3 rounded-xl text-orange-600">
                        <Gift size={24} />
                    </div>
                </div>
            </div>

            {/* Recent Activity Feed */}
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                <div className="flex items-center justify-between mb-6">
                    <h3 className="font-bold text-lg text-gray-800 flex items-center gap-2">
                        <Clock className="text-gray-400" size={20} />
                        Actividad Reciente
                    </h3>
                </div>

                <div className="h-96 overflow-y-auto scrollbar-thin pr-2 space-y-3">
                    {loading ? (
                        <div className="p-8 text-center text-gray-400 italic">Cargando actividad...</div>
                    ) : recentActivity.length === 0 ? (
                        <div className="p-10 text-center text-gray-400 bg-gray-50 rounded-xl">
                            No hay actividad registrada aún.
                        </div>
                    ) : (
                        recentActivity.map((item) => (
                            <div key={item.id} className="flex items-center justify-between p-4 bg-white rounded-xl shadow-sm border border-gray-100 hover:bg-gray-50 transition group">
                                <div className="flex items-center gap-4">
                                    <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${item.type === 'credit'
                                        ? 'bg-green-100 text-green-600'
                                        : 'bg-orange-100 text-orange-600'
                                        }`}>
                                        {item.type === 'credit' ? <ArrowUpRight size={20} /> : <ArrowDownLeft size={20} />}
                                    </div>
                                    <div className="min-w-0">
                                        <p className="text-sm font-bold text-gray-800 line-clamp-1">
                                            {item.userName}
                                        </p>
                                        <p className="text-xs text-gray-500 flex items-center gap-1">
                                            {item.type === 'credit' ? 'Sumó' : 'Canjeó'}
                                            <span className={`font-bold ${item.type === 'credit' ? 'text-green-600' : 'text-orange-600'}`}>
                                                {Math.abs(item.amount)} pts
                                            </span>
                                        </p>
                                    </div>
                                </div>
                                <div className="text-right pl-2 shrink-0">
                                    <div className="text-xs font-semibold text-gray-400 bg-gray-50 px-2 py-1 rounded-md whitespace-nowrap">
                                        {formatTime(item.date)}
                                    </div>
                                    <p className="text-[10px] text-gray-400 mt-1 max-w-[100px] truncate">
                                        {item.concept}
                                    </p>
                                </div>
                            </div>
                        ))
                    )}
                </div>
            </div>
        </div>
    );
};
