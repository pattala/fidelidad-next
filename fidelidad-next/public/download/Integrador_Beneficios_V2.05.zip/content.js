// Club Fidelidad - Content Script (VERSIÓN EMPLEADO V2.05 - document_start + sin blur recovery)
if (window.location.href.includes('fidelidad-next.vercel.app') || window.location.href.includes('/admin') || window.location.href.includes('pattala.com')) {
    console.log("🛑 [Club Fidelidad] Extensión desactivada en el Dashboard.");
} else {
    console.log("🚀 [Club Fidelidad] V2.02: Iniciando extensión con aislamiento Shadow DOM y recuperación de foco.");

let config = { apiUrl: '', apiKey: '' };
let detectedAmount = 0;
let detectedDiscounts = 0;
let processedAmount = null;
let apiRatios = { base: 100, perPeso: 1, discountK: 0 };
let currentPromos = [];
let enablePetModule = false;
let globalAllowEmployeeOverride = false;
let globalStrictMinimumPurchaseBlock = false;
let globalMysteryBoxConfig = null;

const getIdentifier = (item) => item?.socioNumber || item?.phone || item?.telefono || item?.dni || item?.userId || 'unknown';

// SHADOW DOM HELPER

// SHADOW DOM KEYBOARD PROTECTION
function isExtensionInputFocused() {
    const host = document.getElementById('cf-shadow-host');
    if (!host || !host.shadowRoot) return false;
    const shadowActive = host.shadowRoot.activeElement;
    if (!shadowActive) return false;
    const tag = shadowActive.tagName ? shadowActive.tagName.toUpperCase() : '';
    return tag === 'INPUT' || tag === 'TEXTAREA' || shadowActive.isContentEditable === true;
}

function handleExtensionKeyProtection(e) {
    if (isExtensionInputFocused()) {
        // Bloquear TODOS los listeners del POS en esta misma fase (capture)
        e.stopImmediatePropagation();
    }
}

window.addEventListener('keydown', handleExtensionKeyProtection, true);
window.addEventListener('keyup', handleExtensionKeyProtection, true);
window.addEventListener('keypress', handleExtensionKeyProtection, true);

function getOrCreateShadowRoot() {
    let host = document.getElementById('cf-shadow-host');
    if (!host) {
        host = document.createElement('div');
        host.id = 'cf-shadow-host';
        host.className = 'fidelidad-ignore-mutation';
        host.style.cssText = 'position: fixed; top: 0; left: 0; width: 0; height: 0; z-index: 2147483647; pointer-events: none;';
        (document.body || document.documentElement).appendChild(host);

        const shadow = host.attachShadow({ mode: 'open' });

        const style = document.createElement('style');
        style.id = 'cf-all-styles';
        style.textContent = `
            :host { font-family: 'Inter', system-ui, -apple-system, sans-serif; }
            .fidelidad-panel {
                position: fixed; bottom: 20px; right: 20px; width: 330px;
                background: white; border-radius: 20px;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15); z-index: 2147483647 !important;
                pointer-events: auto !important; user-select: text !important; -webkit-user-select: text !important; font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                border: 1px solid #eee; overflow: hidden; display: flex; flex-direction: column;
                animation: fidelidad-slide-up 0.4s cubic-bezier(0.16, 1, 0.3, 1);
            }
            @keyframes fidelidad-slide-up {
                from { transform: translateY(30px); opacity: 0; }
                to { transform: translateY(0); opacity: 1; }
            }
            .fidelidad-header { background: #16a34a; color: white; padding: 12px 16px; display: flex; justify-content: space-between; align-items: center; cursor: move; user-select: none; }
            .fidelidad-header h1 { font-size: 15px; margin: 0; font-weight: 800; letter-spacing: -0.3px; }
            .fidelidad-body { padding: 16px; overflow-y: auto; max-height: 80vh; }
            .cf-tabs { display: flex; gap: 6px; background: #f3f4f6; padding: 3px; border-radius: 10px; margin-bottom: 16px; }
            .cf-tab { flex: 1; border: none; background: transparent; padding: 6px; font-size: 11px; font-weight: 700; color: #6b7280; cursor: pointer; border-radius: 6px; transition: all 0.2s; }
            .cf-tab.active { background: white; color: #16a34a; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05); }
            .cf-label { display: block; font-size: 11px; font-weight: 700; color: #374151; margin-bottom: 4px; }
            .cf-field { margin-bottom: 12px; }
            .fidelidad-input { width: 100%; padding: 10px; border: 1.5px solid #e5e7eb; border-radius: 10px; box-sizing: border-box; font-size: 13px; outline: none; transition: border-color 0.2s; pointer-events: auto !important; user-select: text !important; -webkit-user-select: text !important; }
            .fidelidad-input:focus { border-color: #16a34a; background: #f0fdf4; }
            .cf-input-big { font-size: 20px; font-weight: 900; padding: 10px 14px; }
            .cf-input-group { position: relative; display: flex; align-items: center; }
            .cf-addon { position: absolute; left: 14px; font-weight: 900; color: #9ca3af; font-size: 16px; }
            .cf-input-group input { padding-left: 32px; }
            .cf-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
            .fidelidad-results { background: white; border: 1px solid #e5e7eb; border-radius: 10px; margin-top: 4px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05); max-height: 180px; overflow-y: auto; }
            .fidelidad-result-item { padding: 10px 14px; cursor: pointer; border-bottom: 1px solid #f3f4f6; transition: background 0.2s; }
            .fidelidad-result-item:hover { background: #f0fdf4; }
            .fidelidad-result-item div { font-weight: 700; color: #111827; font-size: 13px; }
            .fidelidad-result-item .dni { font-size: 10px; color: #6b7280; margin-top: 2px; }
            .cf-promos-box { background: #f8fafc; padding: 12px; border-radius: 16px; border: 1px solid #f1f5f9; }
            .cf-promos-list { margin-top: 8px; padding-left: 14px; border-left: 2px solid #e2e8f0; margin-left: 8px; display: flex; flex-direction: column; gap: 8px; }
            #cf-apply-promos:checked~.cf-promos-list { border-left-color: #dcfce7; }
            .cf-promo-item { display: flex; align-items: center; gap: 8px; cursor: pointer; transition: transform 0.1s; }
            .cf-promo-item:active { transform: scale(0.98); }
            .cf-promo-info { display: flex; flex-direction: column; line-height: 1.1; }
            .cf-promo-name { font-size: 10px; font-weight: 800; color: #1e293b; text-transform: uppercase; }
            .cf-promo-status { font-size: 8px; font-weight: 900; padding: 1px 6px; border-radius: 20px; text-transform: uppercase; }
            .cf-promo-status.active { background: #dcfce7; color: #166534; }
            .cf-promo-status.grace { background: #ffedd5; color: #9a3412; }
            .cf-promo-desc { font-size: 9px; font-weight: 700; color: #059669; }
            .cf-promo-time { font-size: 9px; font-weight: 800; color: #a855f7; }
            .cf-checkbox-label { display: flex; align-items: center; gap: 10px; font-size: 12px; font-weight: 700; color: #334155; cursor: pointer; user-select: none; }
            input[type="checkbox"] { width: 16px; height: 16px; accent-color: #16a34a; cursor: pointer; }
            .fidelidad-button { width: 100%; padding: 12px; background: #16a34a; color: white; border: none; border-radius: 12px; font-weight: 800; font-size: 13px; cursor: pointer; margin-top: 16px; transition: transform 0.2s, background 0.2s; }
            .fidelidad-button:hover { background: #15803d; transform: translateY(-1px); }
            .fidelidad-button:active { transform: translateY(0); }
            .fidelidad-button:disabled { background: #d1d5db; cursor: not-allowed; transform: none; }
            .fidelidad-close { cursor: pointer; font-size: 20px; line-height: 1; opacity: 0.7; transition: opacity 0.2s; }
            .fidelidad-close:hover { opacity: 1; }
            .fidelidad-wa-link { display: block; text-align: center; background: #25d366; color: white; text-decoration: none; padding: 12px; border-radius: 10px; margin-top: 10px; font-weight: 800; font-size: 13px; }

            .cf-v35-glass {
                background: rgba(13, 10, 42, 0.98); backdrop-filter: blur(25px); -webkit-backdrop-filter: blur(25px);
                border: 1px solid rgba(255,255,255,0.15); border-radius: 36px;
                box-shadow: 0 50px 100px -20px rgba(0,0,0,0.85); color: white;
                font-family: system-ui, -apple-system, sans-serif; pointer-events: auto;
            }
            .cf-v35-bubble {
                width: 78px; height: 78px; background: linear-gradient(135deg, #6366f1, #8b5cf6);
                border-radius: 50%; display: flex; align-items:center; justify-content:center;
                cursor: grab; border: 4px solid white; box-shadow: 0 20px 50px rgba(99, 102, 241, 0.6);
                transition: transform 0.2s; animation: cf-v35-float 4s infinite ease-in-out; pointer-events: auto;
            }
            .cf-v35-panel { width: 400px; max-height: 580px; display: flex; flex-direction: column; overflow: hidden; animation: cf-v35-pop 0.3s cubic-bezier(0,1,0.2,1); }
            .cf-v35-card { position: relative; background: rgba(255,255,255,0.07); border-radius: 30px; padding: 20px; margin-bottom: 12px; border: 1px solid rgba(255,255,255,0.1); }
            .cf-v35-card-close { position: absolute; top: 15px; right: 15px; background: none; border: none; color: rgba(255,255,255,0.4); font-size: 20px; cursor: pointer; transition: color 0.2s; }
            .cf-v35-card-close:hover { color: #ef4444; }
            .cf-v35-btn-wa {
                background: linear-gradient(135deg, #25D366, #128C7E); color: white; border: none;
                border-radius: 18px; padding: 12px; font-weight: 900; font-size: 12px;
                text-transform: uppercase; cursor: pointer; width: 100%; transition: all 0.2s;
            }
            .cf-v35-btn-wa:hover { filter: brightness(1.1); transform: scale(1.02); }
            @keyframes cf-v35-float { 0%,100% {transform:translateY(0)} 50% {transform:translateY(-12px)} }
            @keyframes cf-v35-pop { from {opacity:0; transform:scale(0.8) translateY(40px)} to {opacity:1; transform:scale(1) translateY(0)} }
            .cf-scrollbar::-webkit-scrollbar { width: 4px; }
            .cf-scrollbar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 10px; }
        `;
        shadow.appendChild(style);
    }
    return host.shadowRoot;
}


// Helper de paridad con Admin
const isChannelEnabled = (cfg, event, channel) => {
    if (channel === 'whatsapp' && !cfg?.messaging?.whatsappEnabled) return false;
    if (channel === 'email' && !cfg?.messaging?.emailEnabled) return false;
    if (channel === 'push' && !cfg?.messaging?.pushEnabled) return false;

    const specific = cfg?.messaging?.eventConfigs?.[event]?.channels;
    if (specific && Array.isArray(specific)) return specific.includes(channel);
    return true;
};

// PUENTE API: Delegar al background para evitar bloqueos CSP/CORS
const apiBridge = (params) => {
    return new Promise((resolve, reject) => {
        if (!chrome.runtime?.id) {
            return reject(new Error("Extension context invalidated. Por favor, refresca la página."));
        }
        chrome.runtime.sendMessage({ action: 'apiCall', params }, (response) => {
            if (chrome.runtime.lastError) {
                const msg = chrome.runtime.lastError.message;
                if (msg.includes('context invalidated')) {
                    return reject(new Error("Extension context invalidated."));
                }
                console.warn("[Bridge] Runtime Error:", msg);
                return reject(new Error(msg));
            }
            if (!response || !response.success) {
                const errorMsg = response?.data?.error || response?.error || 'API Error';
                console.error(`❌ [Club Fidelidad] API Error calling ${params.url}:`, errorMsg);
                return reject(new Error(errorMsg));
            }
            resolve(response.data);
        });
    });
};

// Cargar configuración de storage
chrome.storage.local.get(['appName', 'apiUrl', 'apiKey', 'dismissedAlerts'], (res) => {
    config = res;
    if (res.apiUrl && res.apiKey) {
        // Trigger Engine (Solo motor diario unificado)

        apiBridge({
            url: `${res.apiUrl}/api/engine-daily?mode=daily&trigger=extension`,
            method: 'POST',
            headers: { 'x-api-key': res.apiKey }
        }).then(data => {
                console.log("💎 [Club Fidelidad] API FULL DATA:", data);
                
                const serverProcessed = data.processedAlerts || {};
                chrome.storage.local.get(['dismissedAlerts'], (store) => {
                    let localList = store.dismissedAlerts || [];
                    if (!Array.isArray(localList)) localList = [];

                    // Si el servidor está vacío (reset detectado), limpiar también el storage local
                    // Esto sincroniza la extensión con el clean-start del panel admin
                    if (Object.keys(serverProcessed).length === 0 && localList.length > 0) {
                        localList = [];
                    } else {
                        // MEZCLAR estados del servidor con locales
                        Object.keys(serverProcessed).forEach(id => {
                            const rawStatus = serverProcessed[id];
                            const status = (typeof rawStatus === 'object' && rawStatus !== null) ? rawStatus.status : rawStatus;
                            const exists = localList.find(d => d.id === id);
                            if (!exists) {
                                localList.push({ id, status, timestamp: Date.now() });
                            } else if (exists.status !== status) {
                                exists.status = status; // Prioridad al servidor
                            }
                        });
                    }

                    chrome.storage.local.set({ dismissedAlerts: localList }, () => {
                        
        
        const curY = new Date().getFullYear().toString();
                        const bList = data.birthdays || [];
                        const eList = data.expirations || [];
                        const pList = data.petAlerts || [];
                        const rList = data.redemptions || [];
                        const aList = data.pointsAssignments || [];

                        // GUARDAR CONFIGURACIÓN COMPLETA GLOBALMENTE
                        if (data.config) {
                            config = { ...config, ...data.config };
                        }

                        const getStatus = (id) => {
                            const entry = localList.find(d => d.id === id);
                            return entry ? entry.status : 'pending';
                        };

                        const filteredBirthdays = bList.filter(b => getStatus(`birthday-${getIdentifier(b)}-${curY}`) === 'pending');
                        const filteredExpirations = eList.filter(e => getStatus(`expiration-${getIdentifier(e)}-${e.nextExpirationDate || 'today'}`) === 'pending');
                        const filteredPetAlerts = pList.filter(p => getStatus(`pet-${getIdentifier(p)}-${p.petName}-${p.lastFoodAlertDate || 'today'}`) === 'pending');
                        const filteredRedemptions = rList.filter(r => getStatus(r.alertId) === 'pending');
                        const filteredAssignments = aList.filter(a => getStatus(a.alertId) === 'pending');
                        const filteredCampaigns = (data.campaigns || []).filter(c => getStatus(c.alertId) === 'pending');
                        const filteredMysteryBoxes = (data.mysteryBoxes || []).filter(mb => {
                            if (getStatus(mb.alertId) !== 'pending') return false;
                            const exp = mb.resendExpiresAt || mb.expiresAt;
                            if (exp && new Date(exp) < new Date()) return false;
                            return true;
                        });

                        const total = filteredBirthdays.length + filteredExpirations.length + filteredPetAlerts.length + filteredRedemptions.length + filteredAssignments.length + filteredCampaigns.length + filteredMysteryBoxes.length;
                        const processedData = {
                            ...data,
                            dismissedAlerts: localList,
                            birthdays: { list: bList }, 
                            expirations: { list: eList },
                            petAlerts: { list: pList },
                            redemptions: { list: rList },
                            pointsAssignments: { list: aList },
                            campaigns: { list: data.campaigns || [] }
                        };

                        window._cfFullData = processedData;
                        showGlobalAlert(processedData, config);
                        
                        // Force a refresh of the points preview to reveal elements that depend on the config (like Mystery Box)
                        if (typeof updatePointsPreview === 'function') {
                            updatePointsPreview();
                        } else {
                            // If it's not globally available, dispatch an event
                            window.dispatchEvent(new Event('cf-data-ready'));
                        }
                    });
                });
            }).catch(e => console.error("❌ [Club Fidelidad] Error:", e.message));
    }
});

    if (!document.getElementById('cf-v35-styles')) {
        const style = document.createElement('style');
        style.id = 'cf-v35-styles';
        style.textContent = `
            .cf-v35-glass {
                background: rgba(13, 10, 42, 0.98); backdrop-filter: blur(25px); -webkit-backdrop-filter: blur(25px);
                border: 1px solid rgba(255,255,255,0.15); border-radius: 36px;
                box-shadow: 0 50px 100px -20px rgba(0,0,0,0.85); color: white;
                font-family: system-ui, -apple-system, sans-serif; pointer-events: auto;
            }
            .cf-v35-bubble {
                width: 78px; height: 78px; background: linear-gradient(135deg, #6366f1, #8b5cf6);
                border-radius: 50%; display: flex; align-items:center; justify-content:center;
                cursor: grab; border: 4px solid white; box-shadow: 0 20px 50px rgba(99, 102, 241, 0.6);
                transition: transform 0.2s; animation: cf-v35-float 4s infinite ease-in-out; pointer-events: auto;
            }
            .cf-v35-panel { width: 400px; max-height: 580px; display: flex; flex-direction: column; overflow: hidden; animation: cf-v35-pop 0.3s cubic-bezier(0,1,0.2,1); }
            .cf-v35-card { position: relative; background: rgba(255,255,255,0.07); border-radius: 30px; padding: 20px; margin-bottom: 12px; border: 1px solid rgba(255,255,255,0.1); }
            .cf-v35-card-close { position: absolute; top: 15px; right: 15px; background: none; border: none; color: rgba(255,255,255,0.4); font-size: 20px; cursor: pointer; transition: color 0.2s; }
            .cf-v35-card-close:hover { color: #ef4444; }
            .cf-v35-btn-wa {
                background: linear-gradient(135deg, #25D366, #128C7E); color: white; border: none;
                border-radius: 18px; padding: 12px; font-weight: 900; font-size: 12px;
                text-transform: uppercase; cursor: pointer; width: 100%; transition: all 0.2s;
            }
            .cf-v35-btn-wa:hover { filter: brightness(1.1); transform: scale(1.02); }
            @keyframes cf-v35-float { 0%,100% {transform:translateY(0)} 50% {transform:translateY(-12px)} }
            @keyframes cf-v35-pop { from {opacity:0; transform:scale(0.8) translateY(40px)} to {opacity:1; transform:scale(1) translateY(0)} }
            .cf-scrollbar::-webkit-scrollbar { width: 4px; }
            .cf-scrollbar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 10px; }
        `;
        document.head.appendChild(style);
    }

    const formatDateString = (dateStr) => {
        if (!dateStr || typeof dateStr !== 'string') return 'pronto';
        const parts = dateStr.split('-');
        if (parts.length === 3) {
            return `${parts[2]}/${parts[1]}/${parts[0]}`;
        }
        return dateStr;
    };

    const generateWhatsAppToken = (type, phone, name, extra, cfg, socioNumber, extraDate) => {
        if (!phone) return null;
        let p = phone.replace(/\D/g, '');
        if (!p.startsWith('54') && p.length === 10) p = '549' + p;
        const templates = cfg?.messaging?.templates || {};
        const firstName = name.split(' ')[0];
        const socioInfo = socioNumber ? ` (Socio #${socioNumber})` : "";
        let msg = "";
        
        if (type === 'birthdays') {
            const bPoints = Number(cfg?.birthdayPoints) || 0;
            const tpl = templates.whatsappBirthday || templates.birthday || `¡Feliz cumple {nombre}{socioInfo}! 🎂🎉 Te regalamos {puntos} puntos. ✨`;
            msg = tpl.replace(/{puntos}/g, bPoints.toString());
        } else if (type === 'expirations') {
            const tpl = templates.whatsappExpiration || templates.expirationWarning || `¡Hola {nombre}{socioInfo}! 📢 {puntos} pts por vencer.`;
            const dateStr = extraDate ? formatDateString(extraDate) : 'pronto';
            msg = tpl.replace(/{puntos}/g, extra).replace(/{fecha}/g, dateStr);
        } else if (type === 'petAlerts') {
            const tpl = templates.whatsappPetFood || templates.petFoodAlert || `¡Hola {nombre}{socioInfo}! 🐾 Reposición de {mascota}.`;
            msg = tpl.replace(/{mascota}/g, extra);
        } else if (type === 'redemptions') {
            const tpl = templates.whatsappRedemption || templates.redemption || `¡Canje exitoso {nombre}! 🎁 Canjeaste {premio}. Código: {codigo}`;
            msg = tpl.replace(/{premio}/g, extra).replace(/{codigo}/g, socioNumber);
        } else if (type === 'mysteryBox') {
            const pwaUrl = cfg?.contact?.pwaUrl || cfg?.apiUrl || 'https://fidelidad-next.vercel.app';
            const chanceUrl = `${pwaUrl}/play/${extra}`;
            const defaultTpl = `¡Hola {nombre}! 🎁 ¡Acabas de ganarte un Sorteo Sorpresa! Ingresá a este link para jugar y abrirla: {link}`;
            const tpl = templates.whatsappMysteryBox || defaultTpl;
            msg = tpl.includes('{link}') ? tpl.replace('{link}', chanceUrl) : tpl + '\n\nLink para jugar: ' + chanceUrl;
        } else if (type === 'pointsAssignments') {
            const tpl = templates.whatsappPointsAdded || templates.pointsAdded || `¡Hola {nombre}! 💰 Sumaste {puntos} puntos.`;
            msg = tpl.replace(/{puntos}/g, extra);
        }
        msg = msg.replace(/{nombre}/g, firstName).replace(/{socioInfo}/g, socioInfo).replace(/{tienda}/g, cfg?.siteName || cfg?.appName || 'la tienda');
        return `https://api.whatsapp.com/send?phone=${p}&text=${encodeURIComponent(msg)}`;
    };

    function showGlobalAlert(fullData, config) {
    const curY = new Date().getFullYear().toString();
    const birthdays = fullData.birthdays?.list || [];
    const expirations = fullData.expirations?.list || [];
    const petAlerts = fullData.petAlerts?.list || [];

    let isExpanded = false;
    let activeTab = 'pending'; 
    let pos = { x: 0, y: 0 };
    let dragStart = { x: 0, y: 0 };
    let isDragging = false;

    const shadowRoot = getOrCreateShadowRoot();
    let container = shadowRoot.getElementById('cf-v35-bubble');
    if (container) container.remove();
    container = document.createElement('div');
    container.id = 'cf-v35-bubble';
    container.className = 'fidelidad-ignore-mutation';
    container.style.cssText = `position:fixed; bottom:30px; right:30px; z-index:999999999; pointer-events:none; font-family: 'Outfit', sans-serif;`;

    const mouseUp = () => { isDragging = false; document.removeEventListener('mousemove', onMouseMove); };
    const onMouseMove = (e) => { 
        if (isDragging) {
            pos.x = e.clientX - dragStart.x; pos.y = e.clientY - dragStart.y;
            container.style.transform = `translate(${pos.x}px, ${pos.y}px)`;
        }
    };

    const render = () => {
        const renderMysteryBoxes = (boxes) => {
            if (!boxes || boxes.length === 0) return '<div style="padding:20px; text-align:center; opacity:0.5; font-size:12px;">No hay sorteos pendientes</div>';
            return boxes.map(b => `
                <div style="background:${'#fff7ed'}; border-left:4px solid ${'#fb923c'}; margin-bottom:8px; padding:12px; border-radius:8px; box-shadow:0 2px 4px rgba(0,0,0,0.05);">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <div style="flex:1;">
                            <div style="display:flex; align-items:center; gap:6px;">
                                <span style="font-size:14px;">🎁</span>
                                <span style="font-weight:900; font-size:12px; color:#1f2937;">${b.userName || 'Socio'}</span>
                            </div>
                            <div style="font-size:10px; color:#6b7280; margin-top:4px;">
                                ${b.socioNumber ? 'Socio: ' + b.socioNumber + ' | ' : ''} Tel: ${b.phone || '-'}
                            </div>
                            <div style="font-size:10px; color:#9a3412; margin-top:2px; font-weight:bold;">
                                Monto: ${b.amount || 0}
                            </div>
                            <div style="font-size:9px; opacity:0.8; margin-top:4px; font-weight:700;">
                                🕒 ${(() => {
                                    const d = new Date(b.createdAt || b.timestamp || Date.now());
                                    return d.toLocaleDateString('es-AR') + ' - ' + d.toLocaleTimeString('es-AR', {hour: '2-digit', minute:'2-digit'}) + ' hs';
                                })()}
                            </div>
                        </div>
                        <div style="display:flex; gap:4px;">
                            ${b.phone ? `<button class="cf-action-btn cf-action-whatsapp" data-id="${b.alertId}" data-type="${b.type}" data-phone="${b.phone}" data-name="${b.userName || 'Socio'}" data-extra="${b.id}" style="background:#22c55e; color:white; border:none; padding:6px 10px; border-radius:6px; cursor:pointer; font-weight:bold; font-size:10px;">
                                WA
                            </button>` : ''}
                            <button class="cf-action-btn cf-action-dismiss" data-id="${b.alertId}" data-type="${b.type}" style="background:#e5e7eb; color:#374151; border:none; padding:6px 10px; border-radius:6px; cursor:pointer; font-weight:bold; font-size:10px;">
                                OK
                            </button>
                        </div>
                    </div>
                </div>
            `).join('');
        };

        let ui = container.querySelector('div.cf-v35-glass') || container.querySelector('div.cf-v35-bubble');
        if (!ui) {
            ui = document.createElement('div');
            container.innerHTML = '';
            container.appendChild(ui);
        }
        ui.style.pointerEvents = 'auto';

        const dismissed = fullData.dismissedAlerts || [];
        const getStatus = (id) => {
            const entry = dismissed.find(d => d.id === id);
            return entry ? entry.status : 'pending';
        };

        const curY = new Date().getFullYear().toString();

        const pendingMB = (fullData.mysteryBoxes || []).filter(mb => {
            if (getStatus(mb.alertId) !== 'pending') return false;
            const exp = mb.resendExpiresAt || mb.expiresAt;
            if (exp && new Date(exp) < new Date()) return false;
            return true;
        });
        const pendingB = birthdays.filter(b => getStatus(`birthday-${getIdentifier(b)}-${curY}`) === 'pending');
        const pendingE = expirations.filter(e => getStatus(`expiration-${getIdentifier(e)}-${e.nextExpirationDate || 'today'}`) === 'pending');
        const pendingP = petAlerts.filter(p => getStatus(`pet-${getIdentifier(p)}-${p.petName}-${p.lastFoodAlertDate || 'today'}`) === 'pending');
        const pendingR = (fullData.redemptions?.list || []).filter(r => getStatus(r.alertId) === 'pending');
        const pendingA = (fullData.pointsAssignments?.list || []).filter(a => getStatus(a.alertId) === 'pending');
        
        const procB = birthdays.filter(b => getStatus(`birthday-${getIdentifier(b)}-${curY}`) !== 'pending');
        const procE = expirations.filter(e => getStatus(`expiration-${getIdentifier(e)}-${e.nextExpirationDate || 'today'}`) !== 'pending');
        const procP = petAlerts.filter(p => getStatus(`pet-${getIdentifier(p)}-${p.petName}-${p.lastFoodAlertDate || 'today'}`) !== 'pending');
        const procR = (fullData.redemptions?.list || []).filter(r => getStatus(r.alertId) !== 'pending');
        const procA = (fullData.pointsAssignments?.list || []).filter(a => getStatus(a.alertId) !== 'pending');
        const procC = (fullData.campaigns?.list || []).filter(c => getStatus(c.alertId) !== 'pending');

        const totalPending = pendingB.length + pendingE.length + pendingP.length + pendingR.length + pendingA.length + pendingMB.length + (fullData.campaigns?.list || []).filter(c => getStatus(c.alertId) === 'pending').length;
        const totalProcessed = [...procB, ...procE, ...procP, ...procR, ...procA, ...procC].length;

        if (isExpanded) {
            ui.className = 'cf-v35-glass cf-v35-panel';
            ui.innerHTML = `
                <div style="padding:16px; cursor:grab; border-bottom:1px solid rgba(255,255,255,0.1); display:flex; justify-content:space-between; align-items:center;" id="cf-v35-drag">
                    <div style="display:flex; align-items:center; gap:10px;">
                        <span style="font-size:24px;">\u{1F680}</span>
                        <div>
                            <div style="font-weight:900; font-size:12px; text-transform:uppercase;">Club Fidelidad</div>
                            <div style="font-size:10px; opacity:0.6;">Gestión de Alertas</div>
                        </div>
                    </div>
                    <div style="display:flex; gap:12px; align-items:center;">
                        <button id="cf-v35-open-panel" style="background:#10b981; border:none; color:white; font-size:10px; font-weight:bold; padding:6px 12px; border-radius:6px; cursor:pointer; text-transform:uppercase; box-shadow: 0 4px 10px rgba(16, 185, 129, 0.3); transition:all 0.2s;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                            🎁 Canjear / Cargar
                        </button>
                        <button id="cf-v35-close" style="background:none; border:none; color:white; font-size:24px; cursor:pointer;">×</button>
                    </div>
                </div>
                <div style="display:flex; background:rgba(0,0,0,0.2); padding:4px;">
                    <button id="tab-pending" style="flex:1; padding:8px; border:none; border-radius:8px; font-size:11px; font-weight:800; cursor:pointer; ${activeTab === 'pending' ? 'background:rgba(255,255,255,0.15); color:white;' : 'background:none; color:rgba(255,255,255,0.4);'}">
                        PENDIENTES (${totalPending})
                    </button>
                    <button id="tab-sorteos" style="flex:1; padding:8px; border:none; border-radius:8px; font-size:11px; font-weight:800; cursor:pointer; ${activeTab === 'sorteos' ? 'background:rgba(234,88,12,0.2); color:#fdba74; border: 1px solid rgba(234,88,12,0.3);' : 'background:none; color:rgba(255,255,255,0.4);'}">
                        SORTEOS (${pendingMB.length})
                    </button>
                    <button id="tab-processed" style="flex:1; padding:8px; border:none; border-radius:8px; font-size:11px; font-weight:800; cursor:pointer; ${activeTab === 'processed' ? 'background:rgba(255,255,255,0.15); color:white;' : 'background:none; color:rgba(255,255,255,0.4);'}">
                        PROCESADOS
                    </button>
                </div>
                <div style="padding:16px; overflow-y:auto; flex:1;" class="cf-scrollbar">
                    ${activeTab === 'sorteos' 
                        ? renderMysteryBoxes(pendingMB) 
                        : activeTab === 'pending' ? renderList(pendingB, pendingE, pendingP, pendingR, pendingA, (fullData.campaigns?.list || []).filter(c => getStatus(c.alertId) === 'pending'), 'pending', curY, fullData) : renderList(procB, procE, procP, procR, procA, (fullData.campaigns?.list || []).filter(c => getStatus(c.alertId) !== 'pending'), 'processed', curY, fullData)}
                </div>
            `;
            ui.querySelector('#cf-v35-drag').onmousedown = (e) => {
                isDragging = true; dragStart.x = e.clientX - pos.x; dragStart.y = e.clientY - pos.y;
                document.addEventListener('mousemove', onMouseMove); document.addEventListener('mouseup', mouseUp);
            };
            ui.querySelector('#cf-v35-close').onclick = (e) => { e.stopPropagation(); isExpanded = false; render(); };
            ui.querySelector('#cf-v35-open-panel').onclick = (e) => { 
                e.stopPropagation(); 
                isExpanded = false; 
                render(); 
                window._cfStandaloneMode = true;
                detectedAmount = 0;
                detectedDiscounts = 0;
                showFidelidadPanel(); 
            };
            ui.querySelector('#tab-pending').onclick = () => { activeTab = 'pending'; render(); };
            ui.querySelector('#tab-processed').onclick = () => { activeTab = 'processed'; render(); };
            ui.querySelector('#tab-sorteos').onclick = () => { activeTab = 'sorteos'; render(); };
            attachActions(ui, fullData, render);
        } else {
            ui.className = 'cf-v35-bubble';
            
            // Cálculos para el desglose (V.1.4.32)
            const parts = [];
            if (pendingB.length > 0) parts.push(`C:${pendingB.length}`);
            if (pendingE.length > 0) parts.push(`V:${pendingE.length}`);
            if (pendingP.length > 0) parts.push(`A:${pendingP.length}`);
            if (pendingR.length > 0) parts.push(`R:${pendingR.length}`);
            if (pendingA.length > 0) parts.push(`P:${pendingA.length}`);
            if (pendingMB.length > 0) parts.push(`S:${pendingMB.length}`);
            
            const breakdownHtml = parts.length > 0 
                ? `<div style="position:absolute; bottom:-12px; left:50%; transform:translateX(-50%); background:rgba(0,0,0,0.8); color:white; font-size:8px; font-weight:900; padding:2px 6px; border-radius:10px; white-space:nowrap; border:1px solid rgba(255,255,255,0.2); letter-spacing:0.5px;">${parts.join(' ')}</div>` 
                : "";

            const countHtml = `<div style="position:absolute; top:-8px; right:-8px; background:#ef4444; color:white; font-size:10px; font-weight:900; padding:4px 8px; border-radius:20px; border:2px solid white; box-shadow:0 4px 12px rgba(0,0,0,0.2); pointer-events:none;">${totalPending}</div>`;
            
            ui.innerHTML = `<span style="font-size:28px;">\u{1F4E3}</span>${countHtml}${breakdownHtml}`;
            ui.onmousedown = (e) => {
                isDragging = true; dragStart.x = e.clientX - pos.x; dragStart.y = e.clientY - pos.y;
                document.addEventListener('mousemove', onMouseMove); document.addEventListener('mouseup', mouseUp);
            };
            ui.onclick = (e) => { 
                if (isExpanded) return;
                if (Math.abs(e.clientX - (pos.x + dragStart.x)) < 5) { isExpanded = true; render(); } 
            };
        }
        };

    const renderList = (births, exps, pets, reds, asigs, camps, mode, curY, fullData) => {
        let html = '';
        if (camps && camps.length > 0) {
            html += `<div style="margin-bottom:16px;"><div style="font-size:10px; font-weight:900; color:#3b82f6; text-transform:uppercase; margin-bottom:8px;">\u{1F4E3} Campañas Activas</div>`;
            html += camps.map(c => renderCard(c, 'campaign', c.alertId, mode, fullData)).join('');
            html += `</div>`;
        }
        if (births.length > 0) {
            html += `<div style="margin-bottom:16px;"><div style="font-size:10px; font-weight:900; color:#ec4899; text-transform:uppercase; margin-bottom:8px;">\u{1F382} Cumpleaños</div>`;
            html += births.map(c => renderCard(c, 'birthday', `birthday-${getIdentifier(c)}-${curY}`, mode, fullData)).join('');
            html += `</div>`;
        }
        if (exps.length > 0) {
            html += `<div style="margin-bottom:16px;"><div style="font-size:10px; font-weight:900; color:#f59e0b; text-transform:uppercase; margin-bottom:8px;">\u23F3 Vencimientos</div>`;
            html += exps.map(e => renderCard(e, 'expiration', `expiration-${getIdentifier(e)}-${e.nextExpirationDate || 'today'}`, mode, fullData)).join('');
            html += `</div>`;
        }
        if (pets.length > 0) {
            html += `<div style="margin-bottom:16px;"><div style="font-size:10px; font-weight:900; color:#6366f1; text-transform:uppercase; margin-bottom:8px;">\u{1F43E} Mascotas</div>`;
            html += pets.map(p => renderCard(p, 'pet', `pet-${getIdentifier(p)}-${p.petName}-${p.lastFoodAlertDate || 'today'}`, mode, fullData)).join('');
            html += `</div>`;
        }
        if (reds.length > 0) {
            html += `<div style="margin-bottom:16px;"><div style="font-size:10px; font-weight:900; color:#10b981; text-transform:uppercase; margin-bottom:8px;">\u{1F381} Canjes</div>`;
            html += reds.map(r => renderCard(r, 'redemption', r.alertId, mode, fullData)).join('');
            html += `</div>`;
        }
        if (asigs.length > 0) {
            html += `<div style="margin-bottom:16px;"><div style="font-size:10px; font-weight:900; color:#10b981; text-transform:uppercase; margin-bottom:8px;">\u{1F4B0} Asignaciones</div>`;
            html += asigs.map(a => renderCard(a, 'pointsAssignment', a.alertId, mode, fullData)).join('');
            html += `</div>`;
        }
        return html || '<div style="text-align:center; padding:40px; opacity:0.4;">Sin registros</div>';
    };

    const renderCard = (item, type, id, mode, fullData) => {
        const dismissed = fullData.dismissedAlerts || [];
        const entry = dismissed.find(d => d.id === id);
        const status = entry ? entry.status : 'pending';
        let statusIcon = '';
        if (status === 'sent') statusIcon = '<span style="color:#25D366; font-size:14px; margin-left:auto; filter: drop-shadow(0 0 2px rgba(37,211,102,0.4)); font-weight:bold;">\u2714\u2714</span>';
        if (status === 'dismissed') statusIcon = '<span style="color:#f87171; font-size:14px; margin-left:auto; font-weight:bold;">\u2714</span>';

        // Mapeo de tipos de alerta a eventos de config
        const eventMap = {
            'birthday': 'birthday',
            'expiration': 'expirationWarning',
            'pet': 'petFoodAlert',
            'redemption': 'redemption',
            'pointsAssignment': 'pointsAdded',
            'campaign': 'campaign'
        };
        const eventName = eventMap[type] || type;
        // FORZAR: Siempre mostrar el botón si hay teléfono, para permitir el envío manual
        const showWaBtn = !!(item.phone || item.telefono);

        return `<div class="cf-v35-card" style="${mode === 'processed' ? 'opacity:0.8; filter:grayscale(0.5);' : ''}">
            <div style="display:flex; justify-content:space-between; align-items:start;">
                <div style="flex:1;">
                    <div style="font-weight:800; font-size:14px; display:flex; align-items:center; gap:6px;">
                        ${type === 'campaign' ? 'Campaña Activa' : item.name} 
                        ${type !== 'campaign' ? `<span style="font-size:9px; opacity:0.4;">#${item.socioNumber || 'S/N'}</span>` : ''} 
                        ${statusIcon}
                    </div>
                    <div style="font-size:10px; opacity:0.6; margin-top:2px;">
                        ${type === 'campaign' ? `📢 ${item.name}` : type === 'pet' ? `🐾 ${item.petName}` : type === 'expiration' ? `⏳ ${item.points} pts` : type === 'redemption' ? `🎁 ${item.prizeName}` : type === 'pointsAssignment' ? `💰 +${item.points} pts` : '🎂 Cumpleaños'}
                        <div style="font-size:9px; opacity:0.8; margin-top:4px; font-weight:700;">
                            🕒 ${(() => {
                                const d = new Date(item.timestamp || item.createdAt || Date.now());
                                return d.toLocaleDateString('es-AR') + ' - ' + d.toLocaleTimeString('es-AR', {hour: '2-digit', minute:'2-digit'}) + ' hs';
                            })()}
                        </div>
                    </div>
                </div>
                ${mode === 'pending' ? `<button class="cf-v35-card-close" data-id="${id}">×</button>` : `<button class="cf-v35-card-delete" data-id="${id}" style="background:none; border:none; color:white; opacity:0.4; cursor:pointer;" title="Restaurar a Pendientes">🔄</button>`}
            </div>
            ${type === 'campaign' ? (!item.channels || item.channels.includes('whatsapp') ? `
            <div style="margin-top:10px;">
                <button class="cf-v35-btn-wa" data-id="${id}" data-campid="${item.campId || item.id}" data-type="campaign" style="${mode === 'processed' ? 'background:rgba(255,255,255,0.1);' : ''}">
                    ${mode === 'pending' ? '📥 DESCARGAR CSV' : '📥 VOLVER A DESCARGAR'}
                </button>
            </div>
            ` : '') : showWaBtn ? `
            <div style="margin-top:10px;">
                <button class="cf-v35-btn-wa" data-id="${id}" data-type="${type === 'pet' ? 'petAlerts' : type === 'redemption' ? 'redemptions' : type === 'pointsAssignment' ? 'pointsAssignments' : type + 's'}" data-phone="${item.phone}" data-name="${item.name}" data-socio="${type === 'redemption' ? (item.redemptionCode || '') : (item.socioNumber || '')}" data-extra="${type === 'pet' ? item.petName : type === 'redemption' ? item.prizeName : item.points || ''}" data-date="${item.nextExpirationDate || ''}" style="${mode === 'processed' ? 'background:rgba(255,255,255,0.1);' : ''}">
                    ${mode === 'pending' ? '📳 Enviar WhatsApp' : '🔄 Re-enviar'}
                </button>
            </div>
            ` : ''}
        </div>`;
    };

    const attachActions = (ui, fullData, render) => {
        const updateStorage = async (alertId, status) => {
            // 1. Local Sync (Immediate feedback)
            chrome.storage.local.get(['dismissedAlerts'], (store) => {
                let list = store.dismissedAlerts || [];
                list = list.filter(d => d.id !== alertId);
                if (status) list.push({ id: alertId, status, timestamp: Date.now() });
                chrome.storage.local.set({ dismissedAlerts: list }, () => {
                    fullData.dismissedAlerts = list;
                    render();
                });
            });

            // 2. Cloud Sync (for Dashboard Parity)
            try {
                apiBridge({
                    url: `${config.apiUrl}/api/sync-alerts`,
                    method: 'POST',
                    headers: { 'x-api-key': config.apiKey },
                    body: { 
                        alertId, 
                        action: status || 'delete',
                        date: fullData.referenceDate 
                    }
                });
            } catch (e) { console.warn("Sync error:", e); }
        };
        ui.querySelectorAll('.cf-action-dismiss').forEach(btn => btn.onclick = () => updateStorage(btn.dataset.id, 'dismissed'));
        ui.querySelectorAll('.cf-action-whatsapp').forEach(btn => btn.onclick = async () => {
            const originalText = btn.innerText;
            btn.innerText = '...';
            btn.style.opacity = '0.5';
            btn.style.pointerEvents = 'none';
            
            try {
                let extraId = btn.dataset.extra;
                if (btn.dataset.type === 'mysteryBox') {
                    const res = await apiBridge({
                        url: `${config.apiUrl}/api/regenerate-mystery-box`,
                        method: 'POST',
                        headers: { 'x-api-key': config.apiKey },
                        body: { alertId: btn.dataset.id }
                    });
                    
                    if (res && res.newId) {
                        extraId = res.newId;
                    }
                }
                
                const url = generateWhatsAppToken(btn.dataset.type, btn.dataset.phone, btn.dataset.name, extraId, config, btn.dataset.socio, btn.dataset.date);
                if (url) window.open(url, '_blank');
                updateStorage(btn.dataset.id, 'sent');
            } catch (err) {
                console.error("Error regenerating code:", err);
                alert("Error: " + err.message);
                btn.innerText = originalText;
                btn.style.opacity = '1';
                btn.style.pointerEvents = 'auto';
            }
        });
        ui.querySelectorAll('.cf-v35-card-close').forEach(btn => btn.onclick = () => updateStorage(btn.dataset.id, 'dismissed'));
        ui.querySelectorAll('.cf-v35-card-delete').forEach(btn => btn.onclick = () => updateStorage(btn.dataset.id, null));
        ui.querySelectorAll('.cf-v35-btn-wa').forEach(btn => btn.onclick = () => {
            if (btn.dataset.type === 'campaign') {
                const campId = btn.dataset.campid;
                const originalText = btn.innerHTML;
                btn.innerHTML = '⏳ Generando...';
                btn.style.opacity = '0.5';
                btn.disabled = true;
                apiBridge({
                    url: `${config.apiUrl}/api/engine-campaigns?mode=downloadCSV&campId=${campId}`,
                    method: 'GET',
                    headers: { 'x-api-key': config.apiKey }
                }).then(res => {
                    btn.innerHTML = '✅ Descargado';
                    btn.style.opacity = '1';
                    setTimeout(() => { btn.innerHTML = '📥 VOLVER A DESCARGAR'; btn.disabled = false; updateStorage(btn.dataset.id, 'dismissed'); }, 2000);
                    if (res && res.ok && res.csvContent) {
                        const blob = new Blob(["\uFEFF" + res.csvContent], { type: 'text/csv;charset=utf-8;' });
                        const link = document.createElement("a");
                        const url = URL.createObjectURL(blob);
                        link.setAttribute("href", url);
                        link.setAttribute("download", `Campaña_${campId}_${new Date().toISOString().split('T')[0]}.csv`);
                        link.style.visibility = 'hidden';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    }
                }).catch(e => {
                    console.error(e);
                    btn.innerHTML = '❌ Error';
                    btn.style.opacity = '1';
                    setTimeout(() => { btn.innerHTML = originalText; btn.disabled = false; }, 2000);
                });
            } else {
                const url = generateWhatsAppToken(btn.dataset.type, btn.dataset.phone, btn.dataset.name, btn.dataset.extra, config, btn.dataset.socio, btn.dataset.date);
                if (url) window.open(url, '_blank');
            }
            updateStorage(btn.dataset.id, 'sent');
        });
    };

    render();
    shadowRoot.appendChild(container);
}


// Refresca el contador C/V del widget si ya está visible
// Refresca el contador C/V del widget si ya está visible
async function refreshAlertCounts() {
    if (!config.apiUrl || !config.apiKey) return;
    try {
        const data = await apiBridge({
            url: `${config.apiUrl}/api/engine-daily?mode=daily&trigger=extension`,
            method: 'POST',
            headers: { 'x-api-key': config.apiKey }
        });
        if (data) {
            const serverProcessed = data.processedAlerts || {};
            chrome.storage.local.get(['dismissedAlerts'], (store) => {
                let localList = store.dismissedAlerts || [];
                if (!Array.isArray(localList)) localList = [];

                // MEZCLAR con prioridad al servidor
                Object.keys(serverProcessed).forEach(id => {
                    const rawStatus = serverProcessed[id];
                    const status = (typeof rawStatus === 'object' && rawStatus !== null) ? rawStatus.status : rawStatus;
                    const exists = localList.find(d => d.id === id);
                    if (!exists) localList.push({ id, status, timestamp: Date.now() });
                    else if (exists.status !== status) exists.status = status;
                });

                chrome.storage.local.set({ dismissedAlerts: localList }, () => {
                    const curY = new Date().getFullYear().toString();
                    const bList = data.birthdays || [];
                    const eList = data.expirations || [];
                    const pList = data.petAlerts || [];
                    const rList = data.redemptions || [];
                    const aList = data.pointsAssignments || [];

                    const getStatus = (id) => {
                        const entry = localList.find(d => d.id === id);
                        return entry ? entry.status : 'pending';
                    };

                    const filteredBirthdays = bList.filter(b => getStatus(`birthday-${getIdentifier(b)}-${curY}`) === 'pending');
                    const filteredExpirations = eList.filter(e => getStatus(`expiration-${getIdentifier(e)}-${e.nextExpirationDate || 'today'}`) === 'pending');
                    const filteredPetAlerts = pList.filter(p => getStatus(`pet-${getIdentifier(p)}-${p.petName}-${p.lastFoodAlertDate || 'today'}`) === 'pending');
                    const filteredRedemptions = rList.filter(r => getStatus(r.alertId) === 'pending');
                    const filteredAssignments = aList.filter(a => getStatus(a.alertId) === 'pending');

                    
                    const filteredMysteryBoxes = (data.mysteryBoxes || []).filter(mb => {
                        if (getStatus(mb.alertId) !== 'pending') return false;
                        const exp = mb.resendExpiresAt || mb.expiresAt;
                        if (exp && new Date(exp) < new Date()) return false;
                        return true;
                    });
                    const filteredCampaigns = (data.campaigns || []).filter(c => getStatus(c.alertId) === 'pending');
                    const total = filteredBirthdays.length + filteredExpirations.length + filteredPetAlerts.length + filteredRedemptions.length + filteredAssignments.length + filteredMysteryBoxes.length + filteredCampaigns.length;

                    const processedData = {
                        ...data,
                        dismissedAlerts: localList,
                        birthdays: { list: bList },
                        expirations: { list: eList },
                        petAlerts: { list: pList },
                        redemptions: { list: rList },
                        pointsAssignments: { list: aList },
                        campaigns: { list: data.campaigns || [] }
                    };

                    showGlobalAlert(processedData, config);
                });
            });
        }
    } catch (e) {
        console.warn('[Club Fidelidad] Error refrescando contadores:', e.message);
    }
}

// Auto-refresh when regaining focus (e.g. returning from Admin Panel)
window.addEventListener('focus', () => {
    refreshAlertCounts();
    // Also re-trigger amount detection in case the DOM changed while away
    setTimeout(() => detectAmount(), 500);
});

// Función para buscar el monto en el sitio
function detectAmount() {
    if (window._cfStandaloneMode) return;
    const selectors = [
        '#cpbtc_total',
        'input[name="cpbtc_total"]',
        '#total_pago',
        'input[name="total_pago"]',
        '#monto_pago',
        'input[name="monto_pago"]',
        '#importe_total',
        'input[name="importe_total"]',
        '.total-import'
    ];

    let input = null;
    for (let s of selectors) {
        input = document.querySelector(s);
        if (input) break;
    }

    let val = 0;
    if (input && input.value) {
        val = parseFloat(input.value.replace(/[^0-9.,]/g, '').replace(',', '.'));
    } else {
        const bodyContent = document.body ? (document.body.textContent || '') : '';
        const match = bodyContent.match(/Total a pagar \$:\s*([0-9.,]+)/i) ||
            bodyContent.match(/Total a pagar\s*\$?:\s*([0-9.,]+)/i) ||
            bodyContent.match(/Monto Total\s*\$?:\s*([0-9.,]+)/i);

        if (match && match[1]) {
            val = parseFloat(match[1].replace(/[^0-9.,]/g, '').replace(',', '.'));
        }
    }

    // --- NUEVO: DETECCIÓN DE DESCUENTOS (ITEMS NEGATIVOS) ---
    let discountSum = 0;
    try {
        const rows = document.querySelectorAll('table tbody tr');
        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            // La columna 6 (índice 5) suele ser el Total por ítem
            if (cells.length >= 6) {
                const rowText = row.innerText.toUpperCase();
                const totalText = cells[5].innerText.trim();
                
                // Detectamos por signo menos o por palabras clave de descuento/combo
                const isNegative = totalText.startsWith('-') || totalText.includes('(');
                // --- CONFIGURACIÓN DE PALABRAS CLAVE ---
                // Si necesitas agregar más palabras, agrégalas aquí abajo usando || rowText.includes('NUEVA_PALABRA')
                const hasDiscountKeyword = rowText.includes('DESCUENTO') || 
                                           rowText.includes('PROMO') || 
                                           rowText.includes('COMBO') || 
                                           rowText.includes('BONIF');

                if (isNegative || hasDiscountKeyword) {
                    const numeric = Math.abs(parseFloat(totalText.replace(/[^0-9.,-]/g, '').replace(',', '.')));
                    if (!isNaN(numeric)) discountSum += numeric;
                }
            }
        });
        
        // Detección de descuentos optimizada sin reflows de innerText
        if (discountSum === 0) {
            const potentialElements = document.querySelectorAll('.descuento, .promo, .item-discount, td.text-right, span.discount');
            potentialElements.forEach(el => {
                const text = (el.textContent || '').trim();
                if (((text.startsWith('-$') || (text.startsWith('($') && text.endsWith(')'))) && text.length > 2 && text.length < 20)) {
                    const numeric = Math.abs(parseFloat(text.replace(/[^0-9.,-]/g, '').replace(',', '.')));
                    if (!isNaN(numeric) && numeric > 1) { 
                         discountSum += numeric;
                    }
                }
            });
        }
    } catch (e) {
        console.warn('[Club Fidelidad] Error rastreando descuentos:', e);
    }
    detectedDiscounts = discountSum;

    if (!isNaN(val) && val > 0) {
        if (val === processedAmount) return; // Ya procesado
        const shadow = getOrCreateShadowRoot();
        const panelExists = shadow.getElementById('fidelidad-panel');
        if (val !== detectedAmount || !panelExists) {
            console.log(`💰 [Club Fidelidad] Monto detectado: ${val}`);
            detectedAmount = val;
            showFidelidadPanel();
        }
    } else {
        processedAmount = null;
        // Reset detected amount if no input is found so it can trigger again when it appears
        if (detectedAmount > 0) detectedAmount = 0;
    }
}

let detectTimeout = null;
let lastAlertRefresh = 0;
const observer = new MutationObserver((mutations) => {
    // V.1.99: Ignorar cambios en el host del Shadow Root o dentro del Shadow DOM
    const isExtensionChange = mutations.some(m => {
        const t = m.target;
        if (!t) return false;
        if (t.id === 'cf-shadow-host' || t.closest?.('#cf-shadow-host') || t.getRootNode?.() !== document) return true;
        return t.closest?.('.fidelidad-ignore-mutation') || t.id === 'fidelidad-panel' || t.id === 'cf-v35-bubble';
    });
    if (isExtensionChange) return;

    // Debounce para detección de montos (Siempre activo y rápido)
    if (detectTimeout) clearTimeout(detectTimeout);
    detectTimeout = setTimeout(() => {
        detectAmount();

        // V.1.4.94: Reactividad inteligente con intervalo configurable
        const now = Date.now();
        const intervalMinutes = (config.extensionRefreshInterval || 2);
        const intervalMs = intervalMinutes * 60 * 1000;

        if (now - lastAlertRefresh > intervalMs) {
            lastAlertRefresh = now;
            console.log(`🔄 [Club Fidelidad] Acción detectada: Refrescando alertas (Intervalo: ${intervalMinutes} min)...`);
            refreshAlertCounts();
        }
    }, 150);
});
observer.observe(document.body, { childList: true, subtree: true, attributes: true, characterData: true });

// Initial detection sequence
detectAmount();
setTimeout(detectAmount, 1000);
setTimeout(detectAmount, 2500);

function showFidelidadPanel() {
    const shadowRoot = getOrCreateShadowRoot();
    if (shadowRoot.getElementById('fidelidad-panel')) {
        const amountEl = shadowRoot.getElementById('cf-display-amount');
        const inputMonto = shadowRoot.getElementById('cf-input-amount');
        const baseActual = detectedAmount;

        if (amountEl) {
            amountEl.innerHTML = `$ ${detectedAmount.toLocaleString('es-AR')} ${detectedDiscounts > 0 ? `<span style="font-size: 10px; color: #10b981; font-weight: normal; margin-left:8px;">(Incluye $${detectedDiscounts.toLocaleString('es-AR')} en desc.)</span>` : ''}`;
        }
        
        // Solo actualizar si el input está vacío o aún no tiene el monto detectado (para no pisar cambios manuales)
        if (inputMonto && (!inputMonto.value || inputMonto.dataset.autoFilled === 'true')) {
            inputMonto.value = baseActual;
            inputMonto.dataset.autoFilled = 'true';
        }
        
        // Si el panel estaba minimizado y el monto cambió, lo restauramos
        const body = shadowRoot.querySelector('.fidelidad-body');
        if (body && body.style.display === 'none') {
            body.style.display = 'block';
            shadowRoot.getElementById('fidelidad-close').innerText = '×';
        }

        // --- FIX: Si el panel quedó atrapado en un modal oculto, lo movemos al body o al modal activo ---
        const panel = document.getElementById('fidelidad-panel');
        if (panel && panel.offsetParent === null) {
            let injector = document.body;
            const modalSelectors = ['.modal-content', '.modal-body', '.bootbox', '.ui-dialog-content', '.sky-modal', '[role="dialog"]'];
            for (let sel of modalSelectors) {
                const visibleModal = Array.from(document.querySelectorAll(sel)).find(el => el.offsetParent !== null);
                if (visibleModal) { injector = visibleModal; break; }
            }
            injector.appendChild(panel);
        }

        return;
    }

    const panel = document.createElement('div');
    panel.id = 'fidelidad-panel';
    panel.className = 'fidelidad-panel';

    const _d = new Date();
    const today = `${_d.getFullYear()}-${String(_d.getMonth() + 1).padStart(2, '0')}-${String(_d.getDate()).padStart(2, '0')}`;

    panel.innerHTML = `
        <div class="fidelidad-header">
            <div class="fidelidad-header-title">
                <h1 id="cf-main-title">Sumar Puntos <span style="font-size: 10px; color: #e5e7eb; font-weight: normal; margin-left: 8px; opacity: 0.9;">(${config.appName || config.apiUrl || 'Configurando...'})</span></h1>
                <span id="cf-client-name-header" style="font-size: 10px; opacity: 0.8; display: block;">Seleccione un cliente</span>
            </div>
            <div style="display: flex; gap: 12px; align-items: center;">
                <span id="fidelidad-minimize" style="cursor: pointer; font-size: 20px; font-weight: bold; line-height: 12px; padding-bottom: 8px; opacity: 0.8; transition: opacity 0.2s;" onmouseover="this.style.opacity=1" onmouseout="this.style.opacity=0.8" title="Minimizar">_</span>
                <span class="fidelidad-close" id="fidelidad-close" title="Cerrar y Resetear">&times;</span>
            </div>
        </div>
        <div class="fidelidad-body">
            <!-- BUSCADOR PREDICTIVO -->
            <div class="fidelidad-search-container">
                <label class="cf-label">Buscar Socio (Nombre, DNI o ID)</label>
                <input type="text" id="fidelidad-search" class="fidelidad-input" placeholder="Escriba para buscar..." autocomplete="off">
                <div id="fidelidad-results" class="fidelidad-results" style="display:none;"></div>
            </div>

            <!-- TABS (Solo aparecen cuando hay cliente seleccionado) -->
            <div id="cf-tabs-container" class="cf-tabs" style="display:none; margin-top: 15px;">
                <button class="cf-tab active" data-tab="sumar">Sumar</button>
                <button class="cf-tab" data-tab="canjes">Canjear</button>
            </div>

            <!-- CONTENIDO TAB: SUMAR -->
            <div id="cf-tab-content-sumar" class="cf-tab-content" style="display:none;">
                <div id="cf-points-form">
                    <div class="cf-field">
                        <label id="cf-amount-label" class="cf-label font-bold">Monto de la Compra ($)</label>
                        <div class="cf-input-group">
                            <span id="cf-currency-symbol" class="cf-addon">$</span>
                            <input type="number" id="cf-input-amount" class="fidelidad-input cf-input-big" value="${detectedAmount}" data-auto-filled="true">
                        </div>
                        <div id="cf-display-amount" style="font-size: 11px; margin-top: 4px; color: #6b7280;">
                            $ ${detectedAmount.toLocaleString('es-AR')} ${detectedDiscounts > 0 ? `<span style="color:#10b981; font-weight: bold;">(Incluye $${detectedDiscounts.toLocaleString('es-AR')} en desc.)</span>` : ''}
                        </div>
                        <div id="cf-preview-container" class="cf-preview-box" style="margin-top: 8px; font-size: 12px; color: #6b7280; display: none;">
                            <!-- Preview text will be injected here -->
                        </div>
                    </div>

                    <div class="cf-grid">
                        <div class="cf-field">
                            <label class="cf-label">Concepto</label>
                            <input type="text" id="cf-concept" class="fidelidad-input" value="Compra en local">
                        </div>
                        <div class="cf-field">
                            <label class="cf-label">Fecha</label>
                            <input type="date" id="cf-date" class="fidelidad-input" value="${today}">
                        </div>
                    </div>

                    <!-- PROMOCIONES Y OPCIONES -->
                    <div id="cf-promos-container" class="cf-promos-box" style="margin-top: 20px;">
                        <label class="cf-checkbox-label">
                            <input type="checkbox" id="cf-apply-promos" checked> Aplicar Promociones / Bonus
                        </label>
                        <div id="cf-promos-list" class="cf-promos-list">
                            <!-- Se llena vía API -->
                        </div>
                        <label class="cf-checkbox-label" style="margin-top: 12px; padding-top: 12px; border-top: 1px solid #f3f4f6;">
                            <input type="checkbox" id="cf-notify-wa" ${isChannelEnabled(config, 'pointsAdded', 'whatsapp') ? 'checked' : ''}> Notificar por WhatsApp
                        </label>
                        <!-- Sección Pet: se renderiza dinámicamente si enablePetModule=true y el cliente tiene mascotas -->
                        <div id="cf-pet-food-section" style="display:none; margin-top: 12px; padding-top: 12px; border-top: 1px solid #f3f4f6;">
                            <label class="cf-checkbox-label" style="color: #c2410c; font-weight: 700;">
                                <input type="checkbox" id="cf-pet-food-check"> \u{1F43E} Reposición de Alimento
                            </label>
                            <div id="cf-pet-list" style="display:none; padding-left: 20px; margin-top: 8px; display: flex; flex-wrap: wrap; gap: 6px;"></div>
                        </div>
                    </div>

                    <div id="cf-mystery-box-container" style="display:none; margin-top: 15px; margin-bottom: 15px; padding: 10px; background: #fff7ed; border: 1px dashed #fb923c; border-radius: 12px;">
                        <label style="display:flex; align-items:center; cursor:pointer; gap:8px;">
                            <input type="checkbox" id="cf-generate-mystery-box" checked style="width:16px; height:16px; accent-color:#ea580c;" />
                            <div style="flex:1;">
                                <div style="font-size:12px; font-weight:bold; color:#9a3412;">🎁 Generar Caja Sorpresa</div>
                                <div style="font-size:10px; color:#ea580c;">El cliente recibirá un sorteo por su compra</div>
                            </div>
                        </label>
                    </div>

                    <button id="fidelidad-submit" class="fidelidad-button">Asignar Puntos</button>
                </div>
            </div>

            <!-- CONTENIDO TAB: CANJES -->
            <div id="cf-tab-content-canjes" class="cf-tab-content" style="display:none;">
                <div class="cf-prizes-summary" style="margin-bottom: 12px; background: #eeeff3; padding: 10px; border-radius: 12px; text-align: center;">
                    <span style="font-size: 11px; color: #4b5563; font-weight: 700;">Saldo disponible: <strong id="cf-client-points-balance" style="color: #16a34a; font-size: 14px;">0</strong> pts</span>
                </div>
                <div id="cf-prizes-list" style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; padding: 2px;">
                    <!-- Se llena vía API -->
                </div>
            </div>

            <div id="fidelidad-status" style="margin-top:10px; font-size: 12px; text-align: center;"></div>
        </div>
    `;

    // --- AISLAMIENTO SHADOW DOM (V1.99) ---
    shadowRoot.appendChild(panel);

    // --- V2.02: PREVENIR ROBO DE FOCO - enfoque correcto ---
    // preventDefault en mousedown evita que el browser transfiera el foco a la página
    // NO usamos stopPropagation porque eso rompería el drag del header y del flotante
    panel.addEventListener('mousedown', (e) => {
        // Solo prevenimos el default si el click NO es en un input/textarea/button/select
        // (esos elementos necesitan recibir el foco normalmente)
        const tag = e.target.tagName ? e.target.tagName.toUpperCase() : '';
        const isInteractive = ['INPUT', 'TEXTAREA', 'BUTTON', 'SELECT', 'A'].includes(tag) || e.target.isContentEditable;
        if (!isInteractive) {
            e.preventDefault(); // Evita que el foco se vaya a la página, sin romper drag
        }
    }, false);


    // --- DRAGGABLE LOGIC ---
    let isDragging = false;
    let offset = { x: 0, y: 0 };
    const header = panel.querySelector('.fidelidad-header');

    header.onmousedown = (e) => {
        if (e.target.id === 'fidelidad-close' || e.target.id === 'fidelidad-minimize') return;
        isDragging = true;
        offset.x = e.clientX - panel.offsetLeft;
        offset.y = e.clientY - panel.offsetTop;
        panel.style.transition = 'none';
        header.style.cursor = 'grabbing';
    };

    document.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        panel.style.left = (e.clientX - offset.x) + 'px';
        panel.style.top = (e.clientY - offset.y) + 'px';
        panel.style.bottom = 'auto';
        panel.style.right = 'auto';
    });

    document.addEventListener('mouseup', () => {
        isDragging = false;
        header.style.cursor = 'move';
    });

    // Eventos UI del Panel
    shadowRoot.getElementById('fidelidad-close').onclick = (e) => {
        e.stopPropagation();
        const panel = document.getElementById('fidelidad-panel');
        if (panel) panel.remove();
        // Keyboard protection scoped to panel inputs
        // Reiniciar todo
        selectedClient = null;
        processedAmount = detectedAmount; // Evitar que el observer lo reviva al instante
        if (shadowRoot.getElementById('cf-v35-bubble')) shadowRoot.getElementById('cf-v35-bubble').style.display = 'flex';
    };

    let isMinimized = false;
    shadowRoot.getElementById('fidelidad-minimize').onclick = (e) => {
        e.stopPropagation();
        isMinimized = !isMinimized;
        const body = shadowRoot.querySelector('.fidelidad-body');
        if (isMinimized) {
            body.style.display = 'none';
            shadowRoot.getElementById('fidelidad-minimize').innerText = '□';
            shadowRoot.getElementById('fidelidad-minimize').title = 'Maximizar';
        } else {
            body.style.display = 'block';
            shadowRoot.getElementById('fidelidad-minimize').innerText = '_';
            shadowRoot.getElementById('fidelidad-minimize').title = 'Minimizar';
        }
    };

    // ELEMENTOS
    
    // Auto foco y selección en el buscador de socios
    setTimeout(() => {
        const sInput = shadowRoot.getElementById('fidelidad-search');
        if (sInput) {
            sInput.focus();
            sInput.select();
        }
    }, 250);

    const searchInput = shadowRoot.getElementById('fidelidad-search');
    const resultsDiv = shadowRoot.getElementById('fidelidad-results');
    const pointsForm = shadowRoot.getElementById('cf-points-form');
    const submitBtn = shadowRoot.getElementById('fidelidad-submit');
    const statusDiv = shadowRoot.getElementById('fidelidad-status');
    const clientHeader = shadowRoot.getElementById('cf-client-name-header');
    const promosList = shadowRoot.getElementById('cf-promos-list');
    const inputMonto = shadowRoot.getElementById('cf-input-amount');
    const promosContainer = shadowRoot.getElementById('cf-promos-container');
    const tabsContainer = shadowRoot.getElementById('cf-tabs-container');
    const tabSumar = shadowRoot.getElementById('cf-tab-content-sumar');
    const tabCanjes = shadowRoot.getElementById('cf-tab-content-canjes');
    const prizesList = shadowRoot.getElementById('cf-prizes-list');
    const mainTitle = shadowRoot.getElementById('cf-main-title');
    // MANTENER SIEMPRE EN PESOS EN LA EXTENSIÓN
    let isPesos = true;

    inputMonto.oninput = () => updatePointsPreview();

    // Listen for late-arriving data to update the preview
    window.addEventListener('cf-data-ready', () => {
        updatePointsPreview();
    });

    function updatePointsPreview() {
        const val = parseFloat(inputMonto.value);
        const previewContainer = shadowRoot.getElementById('cf-preview-container');
        if (!previewContainer) return;

        // Auto-show mystery box si esta encendido y val >= minAmount
        const mbxContainer = shadowRoot.getElementById('cf-mystery-box-container');
        const mbCheckbox = shadowRoot.getElementById('cf-generate-mystery-box');
        const mbConfig = globalMysteryBoxConfig || window._cfFullData?.config?.mysteryBox;
        const isSkipped = window._cfFullData?.skipped;
        
        console.log(`[Club Fidelidad] Evaluando Caja Sorpresa. Amount: ${val}, Config:`, mbConfig);
        
        if (mbxContainer && mbConfig && mbConfig.enabled) {
            if (val >= (mbConfig.minAmount || 0)) {
                mbxContainer.style.display = 'block';
                if (mbCheckbox) {
                    if (isSkipped) {
                        mbCheckbox.checked = false;
                        mbCheckbox.disabled = true;
                        mbCheckbox.style.opacity = '0.5';
                        mbCheckbox.style.cursor = 'not-allowed';
                        const labelDiv = mbxContainer.querySelector('div[style*="font-size:12px"]');
                        if (labelDiv && !labelDiv.innerHTML.includes('Fuera de horario')) {
                            labelDiv.innerHTML += ' <span style="color:#ef4444; font-size:10px;">(Fuera de horario)</span>';
                        }
                    } else if (mbConfig.cashierDecision === false) {
                        mbCheckbox.checked = true;
                        mbCheckbox.disabled = true;
                        mbCheckbox.style.opacity = '0.5';
                        mbCheckbox.style.cursor = 'not-allowed';
                        const labelDiv = mbxContainer.querySelector('div[style*="font-size:12px"]');
                        if (labelDiv && labelDiv.innerHTML.includes('Fuera de horario')) {
                            labelDiv.innerHTML = labelDiv.innerHTML.replace(/<span.*Fuera de horario.*<\/span>/g, '');
                        }
                    } else {
                        mbCheckbox.disabled = false;
                        mbCheckbox.style.opacity = '1';
                        mbCheckbox.style.cursor = 'pointer';
                        const labelDiv = mbxContainer.querySelector('div[style*="font-size:12px"]');
                        if (labelDiv && labelDiv.innerHTML.includes('Fuera de horario')) {
                            labelDiv.innerHTML = labelDiv.innerHTML.replace(/<span.*Fuera de horario.*<\/span>/g, '');
                        }
                    }
                }
            } else {
                mbxContainer.style.display = 'none';
            }
        } else if (mbxContainer) {
            mbxContainer.style.display = 'none';
        }

        if (isNaN(val) || val <= 0 || !selectedClient) {
            previewContainer.style.display = 'none';
            return;
        }

        let ptsBase = 0;
        let effectiveVal = val;
        if (isPesos) {
            const curAcc = selectedClient.accumulated_balance || 0;
            if (detectedDiscounts > 0) {
                effectiveVal = Math.max(0, val - detectedDiscounts);
            }
            const total = effectiveVal + curAcc;
            ptsBase = Math.floor((total / (apiRatios.base || 100)) * (apiRatios.perPeso || 1));
        } else {
            ptsBase = Math.floor(val);
        }

        const ptsAfterPromo = ptsBase;

        let bonus = 0;
        const applyPromos = shadowRoot.getElementById('cf-apply-promos').checked;
        if (applyPromos) {
            const selectedIds = Array.from(document.querySelectorAll('.cf-promo-check:checked')).map(el => el.value);
            currentPromos.filter(p => selectedIds.includes(p.id)).forEach(b => {
                const isFlash = b.isFlash;
                const rType = isFlash ? (b.flashRewardType || b.rewardType) : b.rewardType;
                const rValue = isFlash ? (b.flashRewardValue ?? b.rewardValue) : b.rewardValue;

                if (rType === 'MULTIPLIER') bonus += Math.floor(ptsAfterPromo * (rValue - 1));
                else bonus += (rValue || 0);
            });
        }

        // --- FACTOR K: RECUPERACIÓN POR DESCUENTO ---
        let bonusK = 0;
        if (isPesos && detectedDiscounts > 0 && apiRatios.discountK > 0) {
            const ptsPerCurrency = (apiRatios.perPeso || 1) / (apiRatios.base || 100);
            const lostPoints = detectedDiscounts * ptsPerCurrency;
            bonusK = Math.floor(lostPoints * (apiRatios.discountK / 100));
            bonus += bonusK;
        }

        const totalFinal = ptsAfterPromo + bonus;
        previewContainer.style.display = 'block';
        
        previewContainer.innerHTML = `
            <div style="font-weight: bold; color: #374151;">\u2728 Se asignarán: <strong style="color: #059669;">${totalFinal} puntos</strong></div>
            <div style="font-size: 10px; color: #6b7280; margin-top: 2px;">
                Cálculo: $${effectiveVal.toLocaleString('es-AR')} / ${apiRatios.base} x ${apiRatios.perPeso}
                ${(bonus - bonusK) > 0 ? ` + ${bonus - bonusK} pts promos` : ''}
                ${bonusK > 0 ? ` + ${bonusK} pts Bono Descuento (K)` : ''}
            </div>
            ${(detectedDiscounts > 0) ? `<div style="font-size: 10px; color: #ef4444; font-weight: 700;">📉 El sistema restó $${detectedDiscounts.toLocaleString('es-AR')} de descuentos detectados.</div>` : ''}
        `;
    }

    // MASTER TOGGLE PROMOS
    const masterApply = shadowRoot.getElementById('cf-apply-promos');
    masterApply.onchange = (e) => {
        const active = e.target.checked;
        promosList.style.opacity = active ? '1' : '0.4';
        promosList.style.pointerEvents = active ? 'all' : 'none';
        // Disable individual checkboxes to stay in sync with UI
        const checks = promosList.querySelectorAll('.cf-promo-check');
        checks.forEach(c => {
            c.disabled = !active;
        });
        updatePointsPreview();
    };

    // TAB SWITCHING LOGIC
    tabsContainer.querySelectorAll('.cf-tab').forEach(tab => {
        tab.onclick = () => {
            const target = tab.dataset.tab;
            tabsContainer.querySelectorAll('.cf-tab').forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            if (target === 'sumar') {
                tabSumar.style.display = 'block';
                tabCanjes.style.display = 'none';
                mainTitle.innerText = 'Sumar Puntos';
            } else {
                tabSumar.style.display = 'none';
                tabCanjes.style.display = 'block';
                mainTitle.innerText = 'Canjear Premios';
            }
        };
    });

    // Keyboard events are handled via global capture protector handleExtensionKeyProtection

    // Foco inicial en el campo de búsqueda
    setTimeout(() => searchInput.focus(), 300);

    let searchTimeout;
    searchInput.oninput = (e) => {
        clearTimeout(searchTimeout);
        const q = e.target.value;
        if (q.length < 2) {
            resultsDiv.style.display = 'none';
            return;
        }
        resultsDiv.innerHTML = '<div class="fidelidad-result-item" style="text-align:center; color:#888;">Buscando...</div>';
        resultsDiv.style.display = 'block';
        searchTimeout = setTimeout(() => searchClients(q), 150);
    };

    async function searchClients(q) {
        if (!config.apiUrl || !config.apiKey) {
            statusDiv.innerText = '\u26A0\uFE0F Configura la API';
            return;
        }
        try {
            const data = await apiBridge({
                url: `${config.apiUrl}/api/assign-points?q=${encodeURIComponent(q)}`,
                headers: { 'x-api-key': config.apiKey }
            });
            
            if (data && data.ok) {
                apiRatios.base = data.pointsMoneyBase || 100;
                apiRatios.perPeso = data.pointsPerPeso || 1;
                apiRatios.discountK = data.discountRecoveryRatio || 0;
                enablePetModule = data.enablePetModule === true;
                globalAllowEmployeeOverride = data.allowEmployeePrizeOverride === true;
                globalStrictMinimumPurchaseBlock = data.strictMinimumPurchaseBlock === true;
                globalMysteryBoxConfig = data.mysteryBox || null;

                if (data.clients && data.clients.length > 0) {
                    renderResults(data.clients, data.activePromotions || [], data.activePrizes || []);
                    // Refrescar contador C/V del widget (igual que promos: datos frescos en cada búsqueda)
                    refreshAlertCounts();
                } else {
                    resultsDiv.innerHTML = '<div class="fidelidad-result-item" style="cursor:default; color:#666; text-align:center;">No se encontraron socios</div>';
                    resultsDiv.style.display = 'block';
                }
            } else {
                statusDiv.innerText = `\u274C Error: ${data.error || 'Respuesta inválida'}`;
            }
        } catch (e) {
            console.error("🔍 [Club Fidelidad] Error en fetch:", e);
            statusDiv.innerText = '\u274C Error de conexión';
        }
    }

    function renderResults(clients, promotions, allPrizes) {
        resultsDiv.innerHTML = '';
        clients.forEach(c => {
            const item = document.createElement('div');
            item.className = 'fidelidad-result-item';
            item.innerHTML = `
                <div style="font-weight: 700; color: #111827; pointer-events: none;">${c.name}</div>
                <div class="dni" style="font-size: 11px; color: #6b7280; margin-top: 2px; pointer-events: none;">
                    DNI: ${c.dni || 'S/D'} | Socio: ${c.socioNumber || 'N/A'}
                </div>
            `;
            item.onclick = (e) => {
                e.preventDefault();
                e.stopPropagation();

                selectedClient = { id: c.id, name: c.name, accumulated_balance: c.accumulated_balance || 0, pets: c.pets || [] };

                // UI Update
                const ptsBalance = c.accumulated_points ?? (c.points ?? (c.puntos ?? 0));
                
                // Add DNI and Socio number
                const dniText = c.dni ? `DNI: ${c.dni}` : '';
                const socioText = (c.socioNumber || c.numeroSocio) ? `Socio N°: ${c.socioNumber || c.numeroSocio}` : '';
                const extraInfo = [dniText, socioText].filter(Boolean).join(' | ');
                
                clientHeader.innerHTML = `<div style="font-size: 14px; margin-bottom: 3px;">Socio: <strong>${selectedClient.name}</strong> <span style="margin-left: 8px; font-size: 11px; background: #d1fae5; color: #059669; padding: 2px 6px; border-radius: 12px; font-weight: bold; border: 1px solid #34d399;">⭐ ${ptsBalance} pts</span></div>${extraInfo ? `<div style="font-size: 12px; color: #a7f3d0; font-weight: normal;">${extraInfo}</div>` : ''}`;
                
                // Hide search container to save space
                const searchContainer = shadowRoot.querySelector('.fidelidad-search-container');
                if (searchContainer) searchContainer.style.display = 'none';
                
                searchInput.value = selectedClient.name;
                resultsDiv.style.display = 'none';

                pointsForm.style.display = 'block';
                tabSumar.style.display = 'block';
                tabsContainer.style.display = 'flex';
                statusDiv.innerText = '';

                // Actualizar balance en pestaña canjes
                const balanceEl = shadowRoot.getElementById('cf-client-points-balance');
                if (balanceEl) balanceEl.innerText = c.accumulated_points ?? (c.points ?? (c.puntos ?? 0));

                // --- SECCIÓN PET FOOD: Mostrar solo si el módulo está activo y el cliente tiene mascotas ---
                const petFoodSection = shadowRoot.getElementById('cf-pet-food-section');
                const petListDiv = shadowRoot.getElementById('cf-pet-list');
                const clientPets = selectedClient.pets || [];

                if (petFoodSection) {
                    if (enablePetModule && clientPets.length > 0) {
                        petFoodSection.style.display = 'block';
                        
                        function getPetDateHtml(pet, dateField, freqField, defaultFreq) {
                            const rawLastDate = pet[dateField];
                            const cycle = Number(pet[freqField]) || defaultFreq;
                            if (!rawLastDate) return "";
                            
                            let parsedDate = null;
                            if (typeof rawLastDate === 'object' && rawLastDate._seconds) {
                                parsedDate = new Date(rawLastDate._seconds * 1000);
                            } else {
                                parsedDate = new Date(rawLastDate + 'T12:00:00');
                            }
                            parsedDate.setDate(parsedDate.getDate() + cycle);
                            
                            const today = new Date();
                            today.setHours(0,0,0,0);
                            const diffTime = today.getTime() - parsedDate.getTime();
                            const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
                            
                            const formatted = parsedDate.toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit' });
                            
                            if (diffDays > 0) {
                                return ` <span style="color:#dc2626; font-weight:900;">(venció el ${formatted} - hace ${diffDays} días)</span>`;
                            } else {
                                return ` <span style="opacity:0.8;">(vence ${formatted})</span>`;
                            }
                        }

                        let html = '';
                        clientPets.forEach(pet => {
                            const foodText = getPetDateHtml(pet, 'lastPurchaseDate', 'frequencyDays', 30);
                            html += `<label style="display:flex; align-items:center; gap:4px; background:#fff7ed; border:1px solid #fed7aa; padding:4px 8px; border-radius:8px; cursor:pointer; font-size:11px; font-weight:700; color:#9a3412; margin-bottom:4px;">
                                <input type="checkbox" class="cf-pet-check" value="${pet.id}"> 🐾 Alimento ${pet.name || ''}${foodText}
                            </label>`;
                            
                            if ((pet.type || '').toLowerCase().trim() === 'gato') {
                                const litterText = getPetDateHtml(pet, 'lastLitterPurchaseDate', 'litterFrequencyDays', 15);
                                html += `<label style="display:flex; align-items:center; gap:4px; background:#f3f4f6; border:1px solid #d1d5db; padding:4px 8px; border-radius:8px; cursor:pointer; font-size:11px; font-weight:700; color:#374151; margin-bottom:4px;">
                                    <input type="checkbox" class="cf-litter-check" value="${pet.id}"> 💨 Piedras ${pet.name || ''}${litterText}
                                </label>`;
                            }
                        });
                        
                        petFoodSection.innerHTML = html;
                        // Ocultamos el contenedor original porque lo sobreescribimos
                        if (petListDiv) petListDiv.style.display = 'none';

                    } else {
                        petFoodSection.style.display = 'none';
                    }
                }

                // --- TAB CANJES: Renderizar Premios ---
                renderPrizes(allPrizes, (c.accumulated_points ?? (c.points ?? (c.puntos ?? 0))));

                // Renderizar Promos con Lógica de Horarios (Paridad con Admin)
                currentPromos = promotions || [];
                const activePromos = currentPromos.filter(p => p.rewardType === 'FIXED' || p.rewardType === 'MULTIPLIER' || p.rewardType === 'TEXT' || p.rewardType === 'INFO');

                if (activePromos.length > 0) {
                    const GRACE_PERIOD_MINS = 15;

                    function getARTime() {
                        const offsetStored = localStorage.getItem('fiddle_simulated_date_offset');
                        const offset = offsetStored ? parseInt(offsetStored, 10) : 0;
                        const now = new Date();
                        if (offset !== 0) {
                            now.setTime(now.getTime() + (offset * 24 * 60 * 60 * 1000));
                        }

                        const formatter = new Intl.DateTimeFormat('es-AR', {
                            timeZone: 'America/Argentina/Buenos_Aires',
                            hour: '2-digit',
                            minute: '2-digit',
                            second: '2-digit',
                            hour12: false
                        });
                        const parts = formatter.formatToParts(now);
                        const h = parts.find(p => p.type === 'hour').value;
                        const m = parts.find(p => p.type === 'minute').value;
                        // Ensure 2-digit padding for h and m
                        const paddedH = h.padStart(2, '0');
                        const paddedM = m.padStart(2, '0');
                        return { h: Number(h), m: Number(m), hhmm: `${paddedH}:${paddedM}`, now };
                    }

                    promosList.innerHTML = activePromos.map(p => {
                        const isFlash = p.isFlash;
                        const rType = isFlash ? (p.flashRewardType || p.rewardType) : p.rewardType;
                        const rValue = isFlash ? (p.flashRewardValue || p.rewardValue) : p.rewardValue;
                        const rText = isFlash ? (p.flashRewardText || p.rewardText || '') : (p.rewardText || '');
                        const label = rType === 'MULTIPLIER' ? `Multiplicador x${rValue}` : (rType === 'FIXED' ? `Bonus +${rValue} pts` : (rText || 'Promo activa'));
                        const title = p.title || p.name;
                        const timeRange = (p.startTime || p.endTime) ?
                            `<span class="cf-promo-time">⏰ ${p.startTime || '00:00'} a ${p.endTime || '23:59'} hs</span>` : '';

                        return `
                            <label class="cf-promo-item" data-promo-id="${p.id}">
                                <input type="checkbox" class="cf-promo-check" value="${p.id}" checked>
                                <div class="cf-promo-info">
                                    <div style="display: flex; align-items: center; gap: 4px;">
                                        <span class="cf-promo-name">${title}</span>
                                        <div class="cf-promo-status-container" data-id="${p.id}"></div>
                                        ${isFlash ? '<span class="cf-promo-status" style="background:#fef3c7; color:#92400e; font-size: 7px; border: 1px solid #f59e0b;">⚡ FLASH</span>' : ''}
                                    </div>
                                    <div style="display: flex; align-items: center; gap: 6px; margin-top: 2px;">
                                        <span class="cf-promo-desc">${label}</span>
                                        ${timeRange}
                                    </div>
                                </div>
                            </label>
                        `;
                    }).join('');

                    // Función de actualización de contadores
                    if (window.cfTimerInterval) clearInterval(window.cfTimerInterval);

                    const updateTimers = () => {
                        const { h: curH, m: curM, hhmm: curHHmm, now } = getARTime();

                        activePromos.forEach(p => {
                            const promoGraceMins = (p.flashGraceMins !== undefined && p.flashGraceMins !== null) ? Number(p.flashGraceMins) : GRACE_PERIOD_MINS;
                            const container = promosList.querySelector(`.cf-promo-status-container[data-id="${p.id}"]`);
                            if (!container) return;

                            let statusHtml = '';
                            if (p.startTime || p.endTime) {
                                // Transition: Active until the exact second of endTime.
                                // If curHHmm >= p.endTime, it's either in Grace or Expired.
                                const isExpiredToday = p.endTime && curHHmm >= p.endTime;

                                if (isExpiredToday) {
                                    // Calculation for internal grace period (Tolerance)
                                    const [endH, endM] = p.endTime.split(':').map(Number);
                                    const endTimeDate = new Date(now);
                                    endTimeDate.setHours(endH, endM, 0, 0);
                                    let diff = (endTimeDate.getTime() + (promoGraceMins * 60 * 1000)) - now.getTime();

                                    if (diff > 0) {
                                        const mm = Math.floor(diff / (1000 * 60));
                                        const ss = Math.floor((diff % (1000 * 60)) / 1000);
                                        const timeStr = `${mm}:${ss.toString().padStart(2, '0')}`;
                                        statusHtml = `
                                            <span class="cf-promo-status grace">TOLERANCIA</span>
                                            <span class="cf-promo-time" style="color:#9a3412; font-weight:900;">CIERRA EN: ${timeStr}</span>
                                        `;
                                    } else {
                                        // Fully expired and outside grace
                                        statusHtml = '';
                                        const item = promosList.querySelector(`.cf-promo-item[data-promo-id="${p.id}"]`);
                                        if (item) {
                                            item.style.opacity = '0.5';
                                            item.querySelector('input').checked = false;
                                        }
                                    }
                                } else {
                                    const isNotStartedYet = p.startTime && curHHmm < p.startTime;
                                    if (isNotStartedYet) {
                                        statusHtml = `<span class="cf-promo-status" style="background:#f3f4f6; color:#6b7280;">PRÓXIMAMENTE</span>`;
                                    } else {
                                        // Active: Show countdown until the end time
                                        const [endH, endM] = (p.endTime || '23:59').split(':').map(Number);
                                        const endTimeDate = new Date(now);
                                        endTimeDate.setHours(endH, endM, 0, 0);
                                        let diff = endTimeDate.getTime() - now.getTime();

                                        // Protection against negative values just before transition
                                        if (diff < 0) diff = 0;

                                        const mm = Math.floor(diff / (1000 * 60));
                                        const ss = Math.floor((diff % (1000 * 60)) / 1000);
                                        const timeStr = `${mm}:${ss.toString().padStart(2, '0')}`;

                                        statusHtml = `
                                            <span class="cf-promo-status active">¡ACTIVA!</span>
                                            <span class="cf-promo-time" style="color:#166534; font-weight:900;">TERMINA EN: ${timeStr}</span>
                                        `;
                                    }
                                }
                            }
                            container.innerHTML = statusHtml;
                        });
                    };

                    updateTimers();
                    window.cfTimerInterval = setInterval(updateTimers, 1000);

                    // Add listeners to new checkboxes
                    const checks = promosList.querySelectorAll('.cf-promo-check');
                    checks.forEach(check => {
                        check.onchange = () => updatePointsPreview();
                    });
                } else {
                    promosList.innerHTML = '<div style="font-size:10px; color:#999; padding: 5px 0;">No hay promociones disponibles para aplicar.</div>';
                }

                updatePointsPreview();

                // Focus amount input
                setTimeout(() => {
                    const amountInput = shadowRoot.getElementById('cf-input-amount');
                    if (amountInput) amountInput.focus();
                }, 100);
            };
            resultsDiv.appendChild(item);
        });
        resultsDiv.style.display = 'block';
    }

    submitBtn.onclick = async () => {
        if (!selectedClient) return;

        const amount = parseFloat(shadowRoot.getElementById('cf-input-amount').value);
        if (isNaN(amount) || amount <= 0) {
            statusDiv.innerText = '\u274C Ingrese un monto válido';
            return;
        }

        const bonusIds = Array.from(document.querySelectorAll('.cf-promo-check:checked')).map(el => el.value);
        const concept = shadowRoot.getElementById('cf-concept').value;
        const date = shadowRoot.getElementById('cf-date').value;
        const applyWhatsApp = shadowRoot.getElementById('cf-notify-wa').checked;
        const applyPromos = shadowRoot.getElementById('cf-apply-promos').checked;

        // Pet Food Data (solo si el módulo esta activo en esta instancia)
        const petFoodCheck = shadowRoot.getElementById('cf-pet-food-check');
        const isPetFood = petFoodCheck ? petFoodCheck.checked : false;
        const petIds = isPetFood
            ? Array.from(document.querySelectorAll('.cf-pet-check:checked')).map(el => el.value)
            : [];

        // Si no seleccionó ninguna mascota pero marcó el check, tomar todas
        const finalPetIds = (isPetFood && petIds.length === 0 && selectedClient.pets?.length > 0)
            ? selectedClient.pets.map(p => p.id)
            : petIds;

        const litterIds = Array.from(document.querySelectorAll('.cf-litter-check:checked')).map(el => el.value);
        const isPetLitter = litterIds.length > 0;

        submitBtn.disabled = true;
        submitBtn.innerText = 'PROCESANDO...';

        try {
            const data = await apiBridge({
                url: `${config.apiUrl}/api/assign-points`,
                method: 'POST',
                headers: { 'x-api-key': config.apiKey },
                body: {
                    uid: selectedClient.id,
                    amount: isPesos ? Math.max(0, amount - detectedDiscounts) : amount,
                    moneySpent: amount,
                    reason: isPesos ? 'external_integration' : 'manual',
                    concept: concept,
                    date: date,
                    bonusIds: applyPromos ? bonusIds : [],
                    applyWhatsApp: applyWhatsApp,
                    isPetFood: isPetFood,
                    petIds: finalPetIds,
                    isPetLitter: isPetLitter,
                    petLitterIds: litterIds,
                    generateMysteryBox: shadowRoot.getElementById('cf-generate-mystery-box')?.checked || false
                }
            });
            if (data && data.ok) {
                // AUTO-OPEN WHATSAPP if requested
                if (data.whatsappLink && applyWhatsApp) {
                    setTimeout(() => {
                        const link = document.createElement('a');
                        link.href = data.whatsappLink;
                        link.target = '_blank';
                        link.rel = 'noopener noreferrer';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    }, 300);
                }
                renderSuccess(data);
            } else {
                statusDiv.innerText = `\u274C Error: ${data.error}`;
                submitBtn.disabled = false;
                submitBtn.innerText = 'REINTENTAR';
            }
        } catch (e) {
            statusDiv.innerText = '\u274C Error de conexión';
            submitBtn.disabled = false;
        }
    };

    function renderSuccess(data) {
        const body = shadowRoot.querySelector('.fidelidad-body');
        body.innerHTML = `
            <div class="fidelidad-success" style="text-align: center; color: #16a34a; padding: 10px;">
                <div style="font-size: 40px;">✅</div>
                <div style="font-weight: bold; font-size: 18px; margin: 5px 0;">¡Puntos Asignados!</div>
                <div style="font-size: 14px; color: #666; margin-bottom: 15px;">Se sumaron ${data.pointsAdded} puntos a ${selectedClient.name}.</div>
                ${(data.mysteryBoxId && data.showMysteryBoxAlert) ? `
                    <div style="margin-top: 20px; padding: 15px; background: #fff7ed; border: 2px dashed #fb923c; border-radius: 16px;">
                        <div style="font-weight: 900; color: #ea580c; font-size: 14px; margin-bottom: 10px; text-transform: uppercase;">🎁 ¡Caja Sorpresa!</div>
                        <p style="font-size: 11px; color: #9a3412; margin-bottom: 10px; line-height: 1.4;">Avísele al cliente que puede escanear el QR para jugar.</p>
                        <div style="font-size: 18px; color: #fb923c; font-weight: bold; font-family: monospace; background: white; padding: 10px; border-radius: 8px; display: inline-block;">${data.mysteryBoxId}</div>
                    </div>
                ` : ''}
                ${data.whatsappLink ? `<a href="${data.whatsappLink}" target="_blank" class="fidelidad-wa-link" id="cf-wa-link-success">RE-ENVIAR WHATSAPP</a>` : ''}
                <button class="fidelidad-button" style="background:#f3f4f6; color:#374151; margin-top:15px; border: 1px solid #d1d5db;" id="cf-final-close">CERRAR</button>
            </div>
        `;
        // Auto-open WhatsApp si hay link (misma lógica que el panel admin)
        if (data.whatsappLink) {
            setTimeout(() => {
                const link = document.createElement('a');
                link.href = data.whatsappLink;
                link.target = '_blank';
                link.rel = 'noopener noreferrer';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }, 400);
        }
        shadowRoot.getElementById('cf-final-close').onclick = () => {
            // Keyboard protection scoped to panel inputs
            
            
            processedAmount = detectedAmount; // Prevenir que reabra solo
            panel.remove();
        };
    }
    function renderPrizes(prizes, userPoints) {
        const prizesList = shadowRoot.getElementById('cf-prizes-list');
        if (!prizesList) return;

        prizesList.innerHTML = '';
        
        if (window._cfFullData?.skipped) {
            prizesList.innerHTML = '<div style="grid-column: 1 / span 2; text-align: center; color: #ef4444; font-size: 12px; font-weight: bold; padding: 20px;">🚫 Fuera de horario operativo. No se pueden realizar canjes.</div>';
            return;
        }

        if (prizes.length === 0) {
            prizesList.innerHTML = '<div style="grid-column: 1 / span 2; text-align: center; color: #9ca3af; font-size: 12px; padding: 20px;">No hay premios disponibles</div>';
            return;
        }

        const inputMonto = shadowRoot.getElementById('cf-input-amount');
        const getAmount = () => Number(inputMonto?.value) || 0;

        prizes.forEach(p => {
            const card = document.createElement('div');
            card.className = 'cf-prize-card';
            card.dataset.id = p.id;
            card.style.cssText = `
                background: white; border: 1px solid #e5e7eb; border-radius: 12px; padding: 8px;
                display: flex; flex-direction: column; gap: 6px; transition: all 0.2s;
            `;

            let overrideHtml = '';
            if (p.requiresMinimumPurchase && globalAllowEmployeeOverride && !globalStrictMinimumPurchaseBlock) {
                overrideHtml = `
                    <label style="display: flex; align-items: center; gap: 4px; font-size: 9px; color: #6b7280; margin-top: 2px; cursor: pointer;">
                        <input type="checkbox" class="cf-override-check" style="width: 10px; height: 10px;">
                        Ignorar compra mínima
                    </label>
                `;
            }

            card.innerHTML = `
                <div style="height: 60px; background: #f9fafb; border-radius: 8px; display: flex; align-items: center; justify-content: center; overflow: hidden;">
                    ${p.image ? `<img src="${p.image}" style="width: 100%; height: 100%; object-fit: cover;">` : '<span style="font-size: 24px;">\u{1F381}</span>'}
                </div>
                <div style="flex: 1;">
                    <div style="font-size: 11px; font-weight: 800; color: #1f2937; line-height: 1.2; height: 26px; overflow: hidden;">${p.name}</div>
                    ${p.requiresMinimumPurchase ? `<div style="background: #ffedd5; color: #c2410c; font-size: 8px; font-weight: 900; padding: 2px 4px; border-radius: 4px; margin-top: 2px; display: inline-block; text-transform: uppercase;">🛍️ COMPRA MIN: $${p.minimumPurchaseAmount?.toLocaleString('es-AR') || 0}</div>` : ''}
                    ${overrideHtml}
                    <div style="font-size: 12px; font-weight: 900; color: #16a34a; margin-top: 4px;">${p.pointsRequired} pts</div>
                </div>
                <button class="cf-redeem-btn" data-id="${p.id}" style="
                    width: 100%; padding: 6px; border-radius: 6px; border: none;
                    color: white; font-size: 10px; font-weight: 800;
                "></button>
            `;
            prizesList.appendChild(card);
        });

        function updateStates() {
            const currentAmt = getAmount();
            
            prizes.forEach(p => {
                const card = prizesList.querySelector(`.cf-prize-card[data-id="${p.id}"]`);
                if (!card) return;

                const btn = card.querySelector('.cf-redeem-btn');
                const overrideCheck = card.querySelector('.cf-override-check');
                const isOverridden = overrideCheck ? overrideCheck.checked : false;

                const canAfford = userPoints >= p.pointsRequired;
                const hasStock = (p.stock || 0) > 0;
                let meetsMinPurchase = true;

                if (p.requiresMinimumPurchase) {
                    if (globalStrictMinimumPurchaseBlock || globalAllowEmployeeOverride) {
                        if (currentAmt < p.minimumPurchaseAmount) {
                            if (globalStrictMinimumPurchaseBlock) {
                                meetsMinPurchase = false; // Bloqueo total
                            } else if (globalAllowEmployeeOverride && !isOverridden) {
                                meetsMinPurchase = false; // Espera que el empleado tilde
                            }
                        }
                    }
                }

                const isDisabled = !canAfford || !hasStock || !meetsMinPurchase;

                card.style.opacity = isDisabled ? '0.6' : '1';
                card.style.filter = isDisabled ? 'grayscale(0.5)' : 'none';
                card.style.cursor = isDisabled ? 'default' : 'pointer';
                
                btn.disabled = isDisabled;
                btn.style.background = isDisabled ? '#d1d5db' : '#16a34a';
                btn.style.cursor = isDisabled ? 'not-allowed' : 'pointer';

                if (!hasStock) btn.innerText = 'SIN STOCK';
                else if (!canAfford) btn.innerText = 'FALTAN PTS';
                else if (!meetsMinPurchase) btn.innerText = 'COMPRA INSUF.';
                else btn.innerText = 'CANJEAR';

                btn.onclick = isDisabled ? null : () => redeemPrize(p);
            });
        }

        if (inputMonto) inputMonto.addEventListener('input', updateStates);
        prizesList.addEventListener('change', (e) => {
            if (e.target.classList.contains('cf-override-check')) updateStates();
        });

        updateStates();
    }

    async function redeemPrize(prize) {
        if (!confirm(`¿Canjear "${prize.name}" por ${prize.pointsRequired} puntos para ${selectedClient.name}?`)) return;

        const prizesList = shadowRoot.getElementById('cf-prizes-list');
        const originalContent = prizesList.innerHTML;

        prizesList.innerHTML = '<div style="grid-column: 1 / span 2; text-align: center; padding: 40px; color: #16a34a;">Procesando canje...</div>';

        try {
            const data = await apiBridge({
                url: `${config.apiUrl}/api/redeem-prize`,
                method: 'POST',
                headers: { 'x-api-key': config.apiKey },
                body: {
                    uid: selectedClient.id,
                    prizeId: prize.id,
                    purchaseAmount: shadowRoot.getElementById('cf-input-amount')?.value ? Number(shadowRoot.getElementById('cf-input-amount').value) : 0
                }
            });
            if (data && data.ok) {
                renderRedemptionSuccess(data, prize);
            } else {
                alert(`Error al canjear: ${data.error}`);
                prizesList.innerHTML = originalContent;
            }
        } catch (e) {
            alert("Error de conexión al procesar canje");
            prizesList.innerHTML = originalContent;
        }
    }

    function renderRedemptionSuccess(data, prize) {
        const body = shadowRoot.querySelector('.fidelidad-body');
        body.innerHTML = `
            <div class="fidelidad-success" style="text-align: center; color: #16a34a; padding: 10px;">
                <div style="font-size: 40px;">\u{1F381}</div>
                <div style="font-weight: bold; font-size: 18px; margin: 5px 0;">¡Canje Exitoso!</div>
                <div style="font-size: 14px; color: #666; margin-bottom: 15px;">
                    ${selectedClient.name} canjeó <strong>${prize.name}</strong>.<br>
                    Nuevo saldo: <strong>${data.newBalance} pts</strong>.
                </div>
                ${data.whatsappLink ? `<a href="${data.whatsappLink}" target="_blank" class="fidelidad-wa-link">ENVIAR WHATSAPP</a>` : ''}
                <button class="fidelidad-button" style="background:#f3f4f6; color:#374151; margin-top:15px; border: 1px solid #d1d5db;" id="cf-final-close">CERRAR</button>
            </div>
        `;
        shadowRoot.getElementById('cf-final-close').onclick = () => {
            // Keyboard protection scoped to panel inputs
            
            
            processedAmount = detectedAmount; // Prevenir que reabra solo
            panel.remove();
        };
    }
}

}
