import { useEffect, useState } from 'react';
import { X, Calendar, ArrowUpRight, ArrowDownLeft, Clock, History, AlertTriangle, TrendingUp, Trash2, DollarSign } from 'lucide-react';
import { collection, query, orderBy, getDocs, limit, where, doc, writeBatch, increment, getDoc } from 'firebase/firestore';
import { db } from '../../../lib/firebase';
import toast from 'react-hot-toast';

import { ConfigService } from '../../../services/configService';

interface PointsHistoryModalProps {
    client: any;
    onClose: () => void;
}

export const PointsHistoryModal = ({ client, onClose }: PointsHistoryModalProps) => {
    // 1. Local Client State (to show updated points immediately)
    const [currentClient, setCurrentClient] = useState(client);

    const [history, setHistory] = useState<any[]>([]);
    const [nextExpirations, setNextExpirations] = useState<any[]>([]);
    const [totalSpent, setTotalSpent] = useState(0);
    const [loading, setLoading] = useState(true);
    const [config, setConfig] = useState<any>(null);

    // Fetch data wrapper
    const fetchData = async () => {
        if (!client?.id) return;
        try {
            const cfg = await ConfigService.get();
            setConfig(cfg);

            // A. Fetch Latest Client Data (Real-time points)
            const userRef = doc(db, 'users', client.id);
            const userSnap = await getDoc(userRef);
            if (userSnap.exists()) {
                const userData = userSnap.data();
                setCurrentClient({ id: userSnap.id, ...userData });
            }

            // B. Fetch History
            const historyQuery = query(
                collection(db, `users/${client.id}/points_history`),
                orderBy('date', 'desc'),
                limit(50)
            );

            // C. Fetch Next Expirations (Future dates only)
            const expirationQuery = query(
                collection(db, `users/${client.id}/points_history`),
                where('expiresAt', '>', new Date()),
                orderBy('expiresAt', 'asc'),
                limit(2)
            );

            const [historySnap, expirationSnap] = await Promise.all([
                getDocs(historyQuery),
                getDocs(expirationQuery)
            ]);

            let calculatedTotalSpent = 0;

            const historyData = historySnap.docs.map(doc => {
                const d = doc.data();

                // Calcular dinero de este item para el total
                let itemMoney = 0;
                if (d.type === 'credit') {
                    if (d.moneySpent !== undefined && d.moneySpent !== null) {
                        itemMoney = d.moneySpent;
                    } else {
                        // Estimación Legacy
                        const conceptLower = (d.concept || '').toLowerCase();
                        if (!conceptLower.includes('regalo') && !conceptLower.includes('bienvenida') && !conceptLower.includes('bono')) {
                            const ratio = cfg?.pointsPerPeso || 1;
                            const safeRatio = ratio > 0 ? ratio : 1;
                            itemMoney = Math.round((d.amount * 100) / safeRatio);
                        }
                    }
                }
                calculatedTotalSpent += itemMoney;

                return {
                    id: doc.id,
                    ...d,
                    date: d.date?.toDate ? d.date.toDate() : new Date(d.date),
                    expiresAt: d.expiresAt?.toDate ? d.expiresAt.toDate() : (d.expiresAt ? new Date(d.expiresAt) : null)
                };
            });

            const expirationData = expirationSnap.docs.map(doc => ({
                id: doc.id,
                amount: doc.data().amount,
                date: doc.data().expiresAt?.toDate ? doc.data().expiresAt.toDate() : new Date(doc.data().expiresAt)
            }));

            setHistory(historyData);
            setNextExpirations(expirationData.reverse());
            setTotalSpent(calculatedTotalSpent);

        } catch (error) {
            console.error("Error fetching data:", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, [client]);

    // Delete Individual Item
    const handleDeleteItem = async (item: any) => {
        if (!confirm(`¿Eliminar este movimiento de ${item.amount} pts? Se ajustará el saldo del cliente.`)) return;

        setLoading(true);
        try {
            const batch = writeBatch(db);
            const userRef = doc(db, 'users', client.id);
            const historyRef = doc(db, `users/${client.id}/points_history`, item.id);

            // 1. Delete history doc (Subcollection)
            batch.delete(historyRef);

            // 2. Adjust User Balance
            // 'amount' is stored signed (+ for credit, - for debit).
            // To reverse any operation, we simply subtract the stored amount from the balance.
            // Example 1: Deleting a credit of +100. increment(-100). Correct.
            // Example 2: Deleting a redemption of -200. increment(-(-200)) = increment(+200). Correct.

            const adjustment = -item.amount;

            batch.update(userRef, {
                points: increment(adjustment)
            });

            await batch.commit();

            // Note: We are NOT removing from 'historialPuntos' array in 'users' doc 
            // because we lack a unique ID mapping. PWA might show stale history until logic is unified.
            // But 'points' balance will be correct.

            toast.success('Movimiento eliminado y saldo ajustado.');
            fetchData();

        } catch (e) {
            console.error("Error deleting item:", e);
            toast.error("Error al eliminar");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
            <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden animate-scale-up flex flex-col max-h-[85vh]">

                {/* Header */}
                <div className="bg-white border-b border-gray-100 flex flex-col shrink-0">
                    <div className="px-6 py-4 flex justify-between items-start">
                        <div>
                            <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                                <History className="text-blue-500" /> Historial de Puntos
                            </h2>
                            <p className="text-sm text-gray-500">Movimientos de {currentClient.name}</p>
                        </div>
                        <button onClick={onClose} className="text-gray-400 hover:text-gray-600 rounded-full p-1 hover:bg-gray-100 transition">
                            <X size={24} />
                        </button>
                    </div>

                    {/* Stats Dashboard */}
                    <div className="px-6 pb-6 grid grid-cols-3 gap-4">
                        {/* 1. Puntos Disponibles */}
                        <div className="bg-blue-50/50 rounded-xl p-3 border border-blue-100 flex flex-col justify-center">
                            <div className="flex items-center gap-2 mb-1">
                                <TrendingUp size={14} className="text-blue-500" />
                                <p className="text-[10px] font-bold text-blue-600 uppercase tracking-wide">Puntos Actuales</p>
                            </div>
                            <p className="text-2xl font-black text-gray-800">{currentClient.points || 0}</p>
                        </div>

                        {/* 2. Dinero Gastado Total */}
                        <div className="bg-green-50/50 rounded-xl p-3 border border-green-100 flex flex-col justify-center">
                            <div className="flex items-center gap-2 mb-1">
                                <DollarSign size={14} className="text-green-500" />
                                <p className="text-[10px] font-bold text-green-600 uppercase tracking-wide">Total Gastado</p>
                            </div>
                            <p className="text-2xl font-black text-gray-800">
                                ${totalSpent.toLocaleString('es-AR')}
                            </p>
                        </div>

                        {/* 3. Vencimientos */}
                        <div className="bg-orange-50/50 rounded-xl p-3 border border-orange-100 relative overflow-hidden flex flex-col">
                            <div className="flex items-center gap-2 text-orange-700 mb-2">
                                <AlertTriangle size={14} />
                                <p className="text-[10px] font-bold uppercase tracking-wide">Vencimientos</p>
                            </div>
                            {nextExpirations.length === 0 ? (
                                <p className="text-xs text-gray-500 flex items-center gap-1 mt-1">
                                    <Clock size={12} /> Sin datos
                                </p>
                            ) : (
                                <div className="space-y-1">
                                    {nextExpirations.map((exp, idx) => (
                                        <div key={idx} className="flex justify-between items-center text-xs font-medium">
                                            <span className="text-gray-600">{exp.date.toLocaleDateString()}</span>
                                            <span className="text-orange-600 bg-orange-100 px-1 rounded text-[10px]">-{exp.amount}</span>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                {/* Body - List */}
                <div className="flex-1 overflow-y-auto p-0 bg-gray-50/50">
                    {loading ? (
                        <div className="p-10 text-center text-gray-400">Cargando movimientos...</div>
                    ) : history.length === 0 ? (
                        <div className="p-10 text-center flex flex-col items-center text-gray-400">
                            <Clock size={48} className="mb-3 opacity-20" />
                            <p>No hay movimientos registrados.</p>
                        </div>
                    ) : (
                        <table className="w-full text-left text-sm">
                            <thead className="bg-gray-50 text-gray-500 font-semibold sticky top-0 border-b border-gray-200 shadow-sm z-10">
                                <tr>
                                    <th className="p-4 pl-6 bg-gray-50">Fecha</th>
                                    <th className="p-4 bg-gray-50">Concepto</th>
                                    <th className="p-4 text-right bg-gray-50">Dinero ($)</th>
                                    <th className="p-4 text-right bg-gray-50">Puntos</th>
                                    <th className="p-4 text-center bg-gray-50 w-10"></th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100 bg-white">
                                {history.map((item) => (
                                    <tr key={item.id} className="hover:bg-gray-50 transition-colors group">
                                        <td className="p-4 pl-6 text-gray-500 whitespace-nowrap">
                                            <div className="flex items-center gap-2">
                                                <Calendar size={14} className="opacity-50" />
                                                {item.date.toLocaleDateString()} <span className="text-xs opacity-50">{item.date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                            </div>
                                        </td>
                                        <td className="p-4">
                                            <p className="font-medium text-gray-800">{item.concept}</p>
                                            {item.expiresAt && item.type === 'credit' && (
                                                <p className="text-xs text-gray-400 flex items-center gap-1 mt-0.5">
                                                    Vence: {item.expiresAt.toLocaleDateString()}
                                                </p>
                                            )}
                                        </td>
                                        <td className="p-4 text-right">
                                            {item.redeemedValue ? (
                                                // CANJE (Débito)
                                                <div className="flex flex-col items-end">
                                                    <span className="text-xs font-bold text-red-500 bg-red-50 px-2 py-1 rounded">
                                                        Equiv. ${item.redeemedValue}
                                                    </span>
                                                </div>
                                            ) : item.type === 'credit' ? (
                                                // CARGA (Crédito)
                                                <span className={`text-xs font-bold px-2 py-1 rounded ${item.moneySpent > 0 ? 'text-green-600 bg-green-50' : 'text-gray-400 bg-gray-50'}`}>
                                                    {(() => {
                                                        // 1. Si tenemos el dato REAL guardado (NUEVO SISTEMA)
                                                        if (item.moneySpent !== undefined && item.moneySpent !== null) return `$${item.moneySpent}`;

                                                        // 2. Si es histórico, tratamos de adivinar si fue regalo o compra
                                                        const conceptLower = (item.concept || '').toLowerCase();
                                                        const isGift = conceptLower.includes('regalo') ||
                                                            conceptLower.includes('bienvenida') ||
                                                            conceptLower.includes('bono') ||
                                                            conceptLower.includes('ajuste');

                                                        if (isGift) return '$0 (Regalo)';

                                                        // 3. Si parece compra, estimamos
                                                        const ratio = config?.pointsPerPeso || 1;
                                                        // Evitar division por 0
                                                        const safeRatio = ratio > 0 ? ratio : 1;
                                                        const estimated = Math.round((item.amount * 100) / safeRatio);
                                                        return `~$${estimated}`;
                                                    })()}
                                                </span>
                                            ) : '-'}
                                        </td>
                                        <td className="p-4 text-right">
                                            <div className={`inline-flex items-center gap-1 font-bold ${item.amount > 0 ? 'text-green-600' : 'text-red-500'}`}>
                                                {item.amount > 0 ? <ArrowUpRight size={14} /> : <ArrowDownLeft size={14} />}
                                                {item.amount > 0 ? '+' : ''}{item.amount}
                                            </div>
                                        </td>
                                        <td className="p-4 text-center">
                                            <button
                                                onClick={() => handleDeleteItem(item)}
                                                className="p-1.5 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-md transition opacity-0 group-hover:opacity-100"
                                                title="Eliminar movimiento (corrige saldo)"
                                            >
                                                <Trash2 size={16} />
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}
                </div>

                {/* Footer */}
                <div className="p-4 bg-white border-t border-gray-100 shrink-0 text-right flex justify-between items-center">

                    <div className="text-xs text-gray-400 italic">
                        * Eliminar movimientos ajusta automáticamente el saldo del cliente.
                    </div>

                    <button onClick={() => { onClose(); window.location.reload(); }} className="px-5 py-2 bg-gray-100 text-gray-700 font-medium hover:bg-gray-200 rounded-lg transition">
                        Cerrar
                    </button>
                </div>
            </div>
        </div>
    );
};
