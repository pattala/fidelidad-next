import { useEffect, useState } from 'react';
import { CampaignCarousel } from '../components/CampaignCarousel';
import {
    LogOut
} from 'lucide-react';
import { PointsExpirationWarning } from '../components/PointsExpirationWarning';
import { auth, db } from '../../../lib/firebase';
import { doc, onSnapshot } from 'firebase/firestore';
import { useNavigate, useOutletContext } from 'react-router-dom';
import { signOut } from 'firebase/auth';
import { collection, query, orderBy, limit, getDocs } from 'firebase/firestore'; // Added imports

// Subcomponent for the list to keep main component clean
const RecentActivityList = ({ uid }: { uid?: string }) => {
    const [activities, setActivities] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (!uid) return;
        const fetchRecent = async () => {
            try {
                const q = query(
                    collection(db, 'users', uid, 'points_history'),
                    orderBy('date', 'desc'),
                    limit(5)
                );
                const snap = await getDocs(q);
                setActivities(snap.docs.map(d => ({ id: d.id, ...d.data() })));
            } catch (e) {
                console.error(e);
            } finally {
                setLoading(false);
            }
        };
        fetchRecent();
    }, [uid]);

    if (loading) return <div className="w-full h-24 bg-gray-100 rounded-xl animate-pulse"></div>;

    if (activities.length === 0) return (
        <div className="w-full text-center py-4 bg-gray-50 rounded-xl border border-dashed border-gray-200">
            <p className="text-xs text-gray-400">Sin movimientos recientes</p>
        </div>
    );

    return (
        <>
            {activities.map((item) => {
                const isPositive = item.type === 'credit' || (item.amount > 0 && item.type !== 'debit');
                return (
                    <div key={item.id} className="min-w-[140px] bg-white p-3 rounded-2xl shadow-sm border border-gray-100 snap-center flex flex-col gap-2">
                        <div className="flex justify-between items-start">
                            <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${isPositive ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-500'}`}>
                                {isPositive ? '+' : ''}{item.amount}
                            </span>
                            <span className="text-[10px] text-gray-600 font-bold">
                                {item.date?.toDate ? item.date.toDate().toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit' }) : ''}
                            </span>
                        </div>
                        <p className="text-xs font-black text-gray-900 line-clamp-2 leading-tight uppercase tracking-tight">
                            {item.concept || 'Movimiento'}
                        </p>
                    </div>
                );
            })}
        </>
    );
};

export const ClientHomePage = () => {
    const [user, setUser] = useState<any>(null);
    const [userData, setUserData] = useState<any>(null);
    const { config } = useOutletContext<{ config: any }>();
    const navigate = useNavigate();

    const handleLogout = async () => {
        await signOut(auth);
        navigate('/login');
    };

    // 1. Listen for Auth, User Data and General Config
    useEffect(() => {
        const unsubscribeAuth = auth.onAuthStateChanged(async (u) => {
            setUser(u);
            if (u) {
                // Real-time listener for current user data
                const unsubDb = onSnapshot(doc(db, 'users', u.uid), async (document) => {
                    const data = document.data();
                    setUserData(data);
                });
                return () => {
                    unsubDb();
                };
            }
        });
        return () => unsubscribeAuth();
    }, []);

    const displayData = userData || {
        name: user?.displayName || 'Invitado',
        points: 0,
        accumulated_balance: 0
    };

    // Calculate level progress (Gamification Mock)
    const nextLevel = 5000;
    const progressPercent = Math.min((displayData.points / nextLevel) * 100, 100);

    // Calculate missing for next point
    const pointsRatio = Number(config?.pointsPerPeso || 1);
    const moneyBase = Number(config?.pointsMoneyBase || 100);
    const costPerPoint = moneyBase / pointsRatio;

    const rawBalance = Number(displayData.accumulated_balance || 0);
    const balanceForCalc = rawBalance % costPerPoint;
    const missing = Math.ceil(costPerPoint - balanceForCalc);
    const currentBalance = Math.floor(rawBalance);

    return (
        <div className="pb-12 relative overflow-hidden font-sans">

            {/* BACKGROUND DECORATION */}
            <div
                className="absolute top-0 inset-x-0 h-64 z-0 pointer-events-none opacity-20"
                style={{ background: `linear-gradient(to bottom, var(--primary, #9333ea), transparent)` }}
            ></div>

            {/* HEADER OVERLAY / WELCOME */}
            <div className="relative z-10 px-6 pt-6 flex justify-between items-center mb-6">
                <div>
                    <h1 className="text-3xl font-bold text-gray-800 tracking-tight">
                        <span className="block text-sm text-gray-400 font-medium mb-1 uppercase tracking-wider">Hola,</span>
                        {displayData.name} 👋
                    </h1>
                </div>
                <div className="flex items-center gap-2">
                    <button onClick={handleLogout} className="bg-white/80 backdrop-blur-sm p-2.5 rounded-2xl shadow-sm border border-gray-100 text-gray-400 hover:text-red-500 transition" title="Cerrar Sesión">
                        <LogOut size={20} />
                    </button>
                    <div onClick={() => navigate('/profile')} className="bg-white/80 backdrop-blur-sm p-2.5 rounded-2xl shadow-sm border border-gray-100 hover:scale-105 transition cursor-pointer">
                        <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${displayData.name}`} alt="Avatar" className="w-8 h-8 rounded-full" />
                    </div>
                </div>
            </div>

            {/* HERO: THE POINTS BADGE (MATCHING ADMIN MOCKUP) */}
            <div className="relative z-10 px-6 mb-4">
                <div
                    onClick={() => navigate('/profile')}
                    className="rounded-[2.5rem] shadow-xl p-8 pb-10 text-center relative overflow-hidden group cursor-pointer hover:scale-[1.01] transition duration-500"
                    style={{
                        backgroundColor: 'var(--secondary, #3b82f6)',
                        boxShadow: `0 15px 30px -10px rgba(var(--secondary-rgb), 0.4)`
                    }}
                >
                    {/* Subtle inner glow */}
                    <div className="absolute inset-0 bg-gradient-to-tr from-white/10 to-transparent pointer-events-none"></div>

                    <div className="relative z-10">
                        <span className="text-white/70 uppercase text-xs font-bold tracking-widest mb-2 block">Tus Puntos</span>
                        <div className="mb-2">
                            <span className="text-7xl font-black text-white drop-shadow-md">
                                {displayData.points}
                            </span>
                        </div>
                        <span className="text-white/60 text-[10px] uppercase tracking-[0.2em] font-bold block mb-8">Puntos Disponibles</span>

                        {/* Progress Bar (Mock) */}
                        <div className="max-w-[180px] mx-auto">
                            <div className="flex justify-between text-[10px] font-black uppercase tracking-tighter text-white/50 mb-1.5 px-1">
                                <span>Nivel Actual</span>
                                <span>{nextLevel} pts</span>
                            </div>
                            <div className="h-2 w-full bg-black/10 rounded-full overflow-hidden p-0.5 border border-white/10">
                                <div
                                    className="h-full rounded-full transition-all duration-1000 bg-white shadow-[0_0_10px_rgba(255,255,255,0.5)]"
                                    style={{ width: `${progressPercent}%` }}
                                ></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* MONEY EQUIVALENT BANNER (SEPARATE) */}
            {rawBalance > 0 && (
                <div className="relative z-10 px-6 mb-8 animate-fade-in" style={{ animationDelay: '100ms' }}>
                    <div className="bg-white rounded-3xl p-5 shadow-lg border border-gray-100 flex items-center justify-between group hover:shadow-xl transition duration-500">
                        <div className="flex items-center gap-4">
                            <div className="w-12 h-12 rounded-2xl bg-green-50 flex items-center justify-center text-2xl shadow-inner group-hover:scale-110 transition duration-500">
                                💵
                            </div>
                            <div>
                                <p className="text-gray-900 font-black text-2xl leading-none">$ {currentBalance}</p>
                                <p className="text-[10px] text-gray-500 font-bold mt-1 uppercase tracking-tight">Saldo a favor para sumar puntos</p>
                            </div>
                        </div>
                        <div className="text-right">
                            <div className="inline-block px-3 py-1.5 rounded-xl bg-red-50 text-red-600 font-bold text-[10px] shadow-sm transform group-hover:translate-x-[-4px] transition duration-500">
                                Te faltan $ {missing}
                            </div>
                            <p className="text-[8px] text-gray-400 font-black uppercase tracking-tighter mt-1 mr-1">Para +1 punto</p>
                        </div>
                    </div>
                </div>
            )}

            {/* REST OF CONTENT */}
            <div className="px-6 space-y-8 relative z-10">

                {/* Campaigns Carousel */}
                <section>
                    <div className="flex items-center justify-between mb-4 px-1">
                        <h2 className="text-lg font-black text-gray-800 uppercase tracking-tight">Promociones</h2>
                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest bg-gray-100 px-2 py-1 rounded-lg">Exclusivas</span>
                    </div>
                    <CampaignCarousel />
                </section>

                {/* Next Expirations */}
                {user && (
                    <section className="animate-slide-up" style={{ animationDelay: '200ms' }}>
                        <PointsExpirationWarning userId={user.uid} />
                    </section>
                )}

                {/* RECENT ACTIVITY SLIDER */}
                <section className="animate-slide-up" style={{ animationDelay: '300ms' }}>
                    <div className="flex justify-between items-end mb-3 px-1">
                        <h3 className="text-lg font-black text-gray-800 uppercase tracking-tight">Actividad</h3>
                        <span
                            onClick={() => navigate('/activity')}
                            className="text-[10px] font-bold uppercase tracking-widest cursor-pointer hover:opacity-70 transition"
                            style={{ color: 'var(--primary)' }}
                        >
                            Ver todo
                        </span>
                    </div>

                    <div className="bg-white rounded-[2rem] shadow-sm border border-gray-100 h-64 overflow-y-auto scrollbar-hide p-5 space-y-4">
                        <RecentActivityList uid={user?.uid} />
                    </div>
                </section>

                <div className="h-4"></div>
            </div>
        </div>
    );
};
