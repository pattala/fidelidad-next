import React, { useEffect, useState } from 'react';
import { CampaignService, type BonusRule } from '../../../services/campaignService';
import { Megaphone, ChevronRight } from 'lucide-react';

export const CampaignCarousel = () => {
    const [campaigns, setCampaigns] = useState<BonusRule[]>([]);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchCampaigns = async () => {
            try {
                // Use centralized service which handles Date Logic (Start/End) and DaysOfWeek
                const fetchedCampaigns = await CampaignService.getActiveBonusesForToday();
                // Filter only those marked for 'showInApp' and have image or description
                const validCampaigns = fetchedCampaigns.filter(c => c.showInApp && (c.imageUrl || c.description));
                setCampaigns(validCampaigns);
            } catch (error) {
                console.error('Error fetching campaigns:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchCampaigns();
    }, []);

    // Auto-scroll logic
    useEffect(() => {
        if (campaigns.length <= 1) return;
        const interval = setInterval(() => {
            setCurrentIndex(prev => (prev + 1) % campaigns.length);
        }, 6000); // 6 seconds for better readability
        return () => clearInterval(interval);
    }, [campaigns.length]);

    if (loading) return <div className="h-40 bg-gray-100 animate-pulse rounded-2xl mx-4 mb-6"></div>;

    // Empty State: Show generic welcome if no campaigns
    if (campaigns.length === 0) {
        return (
            <div className="mx-4 mb-6 p-6 rounded-2xl bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-lg flex items-center justify-between">
                <div>
                    <h3 className="font-bold text-lg">¡Bienvenido!</h3>
                    <p className="text-indigo-100 text-sm mt-1">Acumula puntos y canjea premios increíbles.</p>
                </div>
                <div className="bg-white/20 p-3 rounded-full backdrop-blur-sm">
                    <Megaphone className="text-white" size={24} />
                </div>
            </div>
        );
    }

    const currentCampaign = campaigns[currentIndex];
    const isTextOnly = !currentCampaign.imageUrl;

    // Gradient palette for text-only ads (random or deterministic based on ID char)
    const gradients = [
        'bg-gradient-to-br from-pink-500 to-rose-500',
        'bg-gradient-to-br from-purple-600 to-indigo-600',
        'bg-gradient-to-br from-blue-400 to-cyan-500',
        'bg-gradient-to-br from-orange-400 to-red-500'
    ];
    // Deterministic selection
    const gradientClass = isTextOnly ? gradients[currentCampaign.id.charCodeAt(0) % gradients.length] : '';

    return (
        <div className="relative mb-8 mx-4 group">
            <div className="relative overflow-hidden rounded-2xl shadow-xl shadow-gray-200/50 h-64 transition-all duration-500">

                {/* SLIDES CONTAINER */}
                <div
                    className="flex transition-transform duration-700 ease-in-out h-full w-full"
                    style={{ transform: `translateX(-${currentIndex * 100}%)` }}
                >
                    {campaigns.map((camp) => {
                        const hasImg = !!camp.imageUrl;
                        // Use custom color OR fallback to gradient generator
                        const gradientBg = gradients[camp.id.charCodeAt(0) % gradients.length];
                        const customStyle = camp.backgroundColor ? { backgroundColor: camp.backgroundColor } : {};
                        const bgClass = camp.backgroundColor ? '' : (hasImg ? 'bg-gray-900' : gradientBg);

                        // Estilos dinámicos
                        const imgFitClass = camp.imageFit === 'cover' ? 'object-cover' : 'object-contain';
                        const fontClass = camp.fontStyle === 'serif' ? 'font-serif' : camp.fontStyle === 'mono' ? 'font-mono' : 'font-sans';

                        // Posición del Texto
                        let textPosClass = 'items-end justify-start text-left'; // Default
                        if (camp.textPosition === 'bottom-center') textPosClass = 'items-end justify-center text-center';
                        if (camp.textPosition === 'bottom-right') textPosClass = 'items-end justify-end text-right';
                        if (camp.textPosition === 'center') textPosClass = 'items-center justify-center text-center';
                        if (camp.textPosition === 'top-left') textPosClass = 'items-start justify-start text-left';
                        if (camp.textPosition === 'top-center') textPosClass = 'items-start justify-center text-center';
                        if (camp.textPosition === 'top-right') textPosClass = 'items-start justify-end text-right';

                        return (
                            <div
                                key={camp.id}
                                className={`min-w-full h-full relative flex ${textPosClass} ${bgClass}`}
                                style={customStyle}
                            >
                                {hasImg ? (
                                    <>
                                        <img
                                            src={camp.imageUrl}
                                            alt={camp.name}
                                            className={`absolute inset-0 w-full h-full ${imgFitClass} p-1 opacity-90`}
                                        />
                                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                                    </>
                                ) : (
                                    // Decorative circles for text-only
                                    <>
                                        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-3xl -mr-10 -mt-10"></div>
                                        <div className="absolute bottom-0 left-0 w-24 h-24 bg-black/10 rounded-full blur-2xl -ml-5 -mb-5"></div>
                                    </>
                                )}

                                {/* CONTENT CONTENT */}
                                <div className={`relative z-10 p-5 text-white ${fontClass} w-full`}>
                                    {camp.showTitle !== false && (
                                        <h3 className={`font-bold leading-tight drop-shadow-sm ${hasImg ? 'text-xl' : 'text-2xl mb-1'}`}>
                                            {camp.name}
                                        </h3>
                                    )}
                                    {camp.description && (
                                        <p className={`opacity-90 leading-snug line-clamp-2 ${hasImg ? 'text-xs text-gray-200 mt-1' : 'text-sm font-medium text-white/90 mt-2'}`}>
                                            {camp.description}
                                        </p>
                                    )}
                                </div>
                            </div>
                        );
                    })}
                </div>

                {/* INDICATORS */}
                {campaigns.length > 1 && (
                    <div className="absolute bottom-3 right-4 flex gap-1.5 z-20">
                        {campaigns.map((_, idx) => (
                            <button
                                key={idx}
                                onClick={() => setCurrentIndex(idx)}
                                className={`h-1.5 rounded-full transition-all duration-300 ${idx === currentIndex ? 'bg-white w-6' : 'bg-white/40 w-2 hover:bg-white/60'}`}
                            />
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};
