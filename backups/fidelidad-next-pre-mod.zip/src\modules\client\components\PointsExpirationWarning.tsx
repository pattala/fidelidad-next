import { useEffect, useState } from 'react';
import { db } from '../../../lib/firebase';
import { collection, query, where, orderBy, limit, getDocs } from 'firebase/firestore';
import { AlertTriangle } from 'lucide-react';


interface Props {
    userId?: string;
}

export const PointsExpirationWarning = ({ userId }: Props) => {
    const [nextExpirations, setNextExpirations] = useState<{ amount: number, date: Date }[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchExpirations = async () => {
            if (!userId) {
                setLoading(false);
                return;
            }

            try {
                // Look for points expiring in the future
                const today = new Date();

                const q = query(
                    collection(db, `users/${userId}/points_history`),
                    where('expiresAt', '>', today),
                    orderBy('expiresAt', 'asc'),
                    limit(2) // Get next 2 expirations
                );

                const snapshot = await getDocs(q);
                const expirations: { amount: number, date: Date }[] = [];
                let totalExpiring = 0;

                snapshot.forEach(doc => {
                    const data = doc.data();
                    if (data.amount > 0) {
                        totalExpiring += data.amount;
                        const date = data.expiresAt?.toDate ? data.expiresAt.toDate() : new Date(data.expiresAt);
                        expirations.push({ amount: data.amount, date });
                    }
                });

                setNextExpirations(expirations.reverse());

            } catch (error) {
                console.error("Error fetching expirations:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchExpirations();
    }, [userId]);

    if (loading) return null;
    if (nextExpirations.length === 0) return null;

    return (
        <div className="bg-gray-800 rounded-2xl p-4 shadow-md border border-gray-700">
            <div className="flex items-start gap-3">
                <div
                    className="p-2 rounded-full mt-1"
                    style={{ backgroundColor: 'var(--primary, #9333ea)22' }}
                >
                    <AlertTriangle style={{ color: 'var(--primary, #9333ea)' }} size={18} />
                </div>
                <div className="flex-1">
                    <h4 className="font-bold text-white text-sm leading-tight mb-2">
                        Próximos Vencimientos
                    </h4>
                    <div className="space-y-2">
                        {nextExpirations.map((exp, idx) => (
                            <div key={idx} className="flex justify-between items-center text-xs">
                                <span className="text-gray-300">
                                    El {exp.date.toLocaleDateString('es-AR', { day: 'numeric', month: 'short', year: 'numeric' })}
                                </span>
                                <span className="text-red-300 font-bold bg-red-900/30 px-2 py-0.5 rounded">
                                    {exp.amount} pts
                                </span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};
