export interface Client {
    id: string;
    name: string;
    email: string;
    dni: string;
    phone: string;
    socioNumber?: string;
    points: number;
    accumulated_balance?: number;
    tags?: string[];
    createdAt?: any;
    // Address fields
    calle?: string;
    piso?: string;
    depto?: string;
    provincia?: string;
    partido?: string;
    localidad?: string;
    cp?: string;
    formatted_address?: string;
    google_maps_link?: string;
}

export interface User {
    uid: string;
    email: string | null;
    displayName: string | null;
    photoURL?: string | null;
}

export type MessagingChannel = 'whatsapp' | 'email' | 'push';

export interface AppConfig {
    // Branding
    siteName: string;
    primaryColor: string;
    secondaryColor: string;
    backgroundColor?: string;
    logoUrl: string;

    // Contacto & Redes
    contact?: {
        whatsapp?: string; // Different from messaging.whatsappPhoneNumber? Maybe keep separate as "Display/Support" number vs "System" number, or sync them. User said "numero de contacto".
        email?: string;
        instagram?: string;
        facebook?: string;
        website?: string;
        termsAndConditions?: string; // URL for TyC
    };

    // Reglas del Negocio (Points Logic)
    pointsPerPeso?: number;
    pointsMoneyBase?: number;
    welcomePoints?: number;

    // Vencimiento por Rangos
    expirationRules?: Array<{
        minPoints: number;
        maxPoints: number | null;
        validityDays: number;
    }>;

    // Mensajería
    messaging?: {
        emailEnabled: boolean;
        whatsappEnabled: boolean;
        pushEnabled: boolean;
        whatsappPhoneNumber?: string;
        whatsappDefaultMessage?: string;

        eventConfigs?: {
            welcome?: { channels: MessagingChannel[] };
            pointsAdded?: { channels: MessagingChannel[] };
            redemption?: { channels: MessagingChannel[] };
            campaign?: { channels: MessagingChannel[] };
            offer?: { channels: MessagingChannel[] };
        };

        templates?: {
            pointsAdded?: string;
            redemption?: string;
            welcome?: string;
            campaign?: string;
            offer?: string;
        };
    };
}

export interface Prize {
    id: string;
    name: string;
    pointsRequired: number;
    stock: number;
    description?: string;
    active: boolean;
    imageUrl?: string;
    cashValue?: number; // Valor en pesos para reportes
}
