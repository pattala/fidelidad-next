import { useEffect, useState } from 'react';
import { Home, Gift, User, MessageCircle, X } from 'lucide-react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { doc, onSnapshot, collection, query, where } from 'firebase/firestore';
import { db, auth } from '../../../lib/firebase';

export const ClientLayout = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const [config, setConfig] = useState<any>({
        siteName: 'Club RAMPET',
        primaryColor: '#9333ea', // Default Purple
        secondaryColor: '#3b82f6', // Default Blue
        logoUrl: '',
        contact: {}
    });

    // Notifications State
    const [unreadCount, setUnreadCount] = useState(0);
    const [isContactOpen, setIsContactOpen] = useState(false);

    // Listen for Unread Notifications
    useEffect(() => {
        if (!auth.currentUser) return;

        // We could also listen to auth state changes here if we wanted to be 100% safe
        const q = query(
            collection(db, `users/${auth.currentUser.uid}/inbox`),
            where('read', '==', false)
        );

        const unsubUtils = onSnapshot(q, (snap) => {
            setUnreadCount(snap.docs.length);
        });

        return () => unsubUtils();
    }, []);

    useEffect(() => {
        const unsub = onSnapshot(doc(db, 'config/general'), (snap) => {
            if (snap.exists()) {
                const data = snap.data();
                setConfig({
                    siteName: data.siteName || 'Club RAMPET',
                    primaryColor: data.primaryColor || '#9333ea',
                    secondaryColor: data.secondaryColor || '#3b82f6',
                    backgroundColor: data.backgroundColor || '#f9fafb',
                    logoUrl: data.logoUrl || '',
                    contact: data.contact || {},
                    pointsPerPeso: data.pointsPerPeso || 1,
                    pointsMoneyBase: data.pointsMoneyBase || 100,
                });
                // Dynamic Theme Injection
                const hexToRgb = (hex: string) => {
                    const r = parseInt(hex.slice(1, 3), 16);
                    const g = parseInt(hex.slice(3, 5), 16);
                    const b = parseInt(hex.slice(5, 7), 16);
                    return `${r}, ${g}, ${b}`;
                };

                document.documentElement.style.setProperty('--primary', data.primaryColor || '#9333ea');
                document.documentElement.style.setProperty('--secondary', data.secondaryColor || '#3b82f6');
                document.documentElement.style.setProperty('--background', data.backgroundColor || '#f9fafb');
                document.documentElement.style.setProperty('--primary-rgb', hexToRgb(data.primaryColor || '#9333ea'));
                document.documentElement.style.setProperty('--secondary-rgb', hexToRgb(data.secondaryColor || '#3b82f6'));
                document.documentElement.style.setProperty('--background-rgb', hexToRgb(data.backgroundColor || '#f9fafb'));
            }
        });
        return () => unsub();
    }, []);

    const isActive = (path: string) => location.pathname === path;

    return (
        <div
            className="flex flex-col min-h-screen max-w-md mx-auto shadow-2xl overflow-hidden relative font-sans transition-colors duration-500"
            style={{ backgroundColor: 'var(--background, #f9fafb)' }}
        >

            {/* Header / Top Bar */}
            <header
                className="px-4 py-3 pb-2 sticky top-0 z-20 flex items-center justify-between border-b border-white/10 backdrop-blur-md text-white transition-colors duration-500"
                style={{ backgroundColor: 'var(--primary, #9333ea)' }}
            >
                <div className="flex items-center gap-2">
                    <div className="bg-white p-1 rounded-full shadow-sm">
                        <img
                            src={config.logoUrl || "/logo.png"}
                            alt="Logo"
                            className="h-7 w-7 object-contain"
                            onError={(e) => e.currentTarget.src = 'https://placehold.co/100x100?text=LOGO'}
                        />
                    </div>
                    <span className="font-bold text-lg tracking-tight">
                        {config.siteName}
                    </span>
                </div>
                <div className="relative">
                    <button
                        onClick={() => navigate('/inbox')}
                        className="p-2 rounded-full hover:bg-white/10 transition relative"
                    >
                        <span className="text-xl">🔔</span>
                        {unreadCount > 0 && (
                            <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 rounded-full border-2 border-[var(--primary)] flex items-center justify-center text-[9px] font-bold text-white shadow-sm">
                                {unreadCount > 9 ? '9+' : unreadCount}
                            </span>
                        )}
                    </button>
                </div>
            </header>

            {/* Main Content Area */}
            <main className="flex-1 overflow-y-auto pb-24 scrollbar-hide">
                <div className="animate-fade-in">
                    <Outlet context={{ config }} />
                </div>
            </main>

            {/* Bottom Navigation */}
            <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-gray-100 px-6 py-2 pb-5 z-30 flex justify-between items-center shadow-lg-up">
                <button
                    onClick={() => navigate('/')}
                    className={`flex flex-col items-center gap-1 transition-all duration-300 ${isActive('/') ? 'scale-110' : 'text-gray-500 hover:text-gray-700'}`}
                    style={{ color: isActive('/') ? 'var(--primary)' : undefined }}
                >
                    <Home size={26} strokeWidth={isActive('/') ? 2.5 : 2} className={isActive('/') ? "opacity-100" : "opacity-80"} />
                    <span
                        className={`text-[10px] font-black uppercase tracking-tighter ${isActive('/') ? 'text-transparent bg-clip-text' : 'text-gray-600'}`}
                        style={isActive('/') ? { backgroundImage: `linear-gradient(to right, var(--primary), var(--secondary))` } : {}}
                    >
                        Inicio
                    </span>
                </button>

                <button
                    onClick={() => navigate('/rewards')}
                    className={`flex flex-col items-center gap-1 transition-all duration-300 ${isActive('/rewards') ? 'scale-110' : 'text-gray-500 hover:text-gray-700'}`}
                    style={{ color: isActive('/rewards') ? 'var(--primary)' : undefined }}
                >
                    <Gift size={26} strokeWidth={isActive('/rewards') ? 2.5 : 2} className={isActive('/rewards') ? "opacity-100" : "opacity-80"} />
                    <span
                        className={`text-[10px] font-black uppercase tracking-tighter ${isActive('/rewards') ? 'text-transparent bg-clip-text' : 'text-gray-600'}`}
                        style={isActive('/rewards') ? { backgroundImage: `linear-gradient(to right, var(--primary), var(--secondary))` } : {}}
                    >
                        Premios
                    </span>
                </button>

                <button
                    onClick={() => setIsContactOpen(true)}
                    className={`flex flex-col items-center gap-1 transition-all duration-300 ${isContactOpen ? 'scale-110' : 'text-gray-500 hover:text-gray-700'}`}
                    style={{ color: isContactOpen ? 'var(--primary)' : undefined }}
                >
                    <MessageCircle size={26} strokeWidth={isContactOpen ? 2.5 : 2} className={isContactOpen ? "opacity-100" : "opacity-80"} />
                    <span
                        className={`text-[10px] font-black uppercase tracking-tighter ${isContactOpen ? 'text-transparent bg-clip-text' : 'text-gray-600'}`}
                        style={isContactOpen ? { backgroundImage: `linear-gradient(to right, var(--primary), var(--secondary))` } : {}}
                    >
                        Contacto
                    </span>
                </button>

                <button
                    onClick={() => navigate('/activity')}
                    className={`flex flex-col items-center gap-1 transition-all duration-300 ${isActive('/activity') ? 'scale-110' : 'text-gray-500 hover:text-gray-700'}`}
                    style={{ color: isActive('/activity') ? 'var(--primary)' : undefined }}
                >
                    <span className={`text-2xl leading-none transition-all ${isActive('/activity') ? 'grayscale-0 opacity-100' : 'grayscale opacity-80'}`}>🧾</span>
                    <span
                        className={`text-[10px] font-black uppercase tracking-tighter ${isActive('/activity') ? 'text-transparent bg-clip-text' : 'text-gray-600'}`}
                        style={isActive('/activity') ? { backgroundImage: `linear-gradient(to right, var(--primary), var(--secondary))` } : {}}
                    >
                        Actividad
                    </span>
                </button>

                <button
                    onClick={() => navigate('/profile')}
                    className={`flex flex-col items-center gap-1 transition-all duration-300 ${isActive('/profile') ? 'scale-110' : 'text-gray-500 hover:text-gray-700'}`}
                    style={{ color: isActive('/profile') ? 'var(--primary)' : undefined }}
                >
                    <User size={26} strokeWidth={isActive('/profile') ? 2.5 : 2} className={isActive('/profile') ? "opacity-100" : "opacity-80"} />
                    <span
                        className={`text-[10px] font-black uppercase tracking-tighter ${isActive('/profile') ? 'text-transparent bg-clip-text' : 'text-gray-600'}`}
                        style={isActive('/profile') ? { backgroundImage: `linear-gradient(to right, var(--primary), var(--secondary))` } : {}}
                    >
                        Perfil
                    </span>
                </button>
            </nav>

            {/* Contact Modal */}
            {isContactOpen && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm animate-fade-in">
                    <div className="bg-white w-full max-w-xs rounded-3xl overflow-hidden shadow-2xl animate-scale-up border border-gray-100">
                        <div className="p-6 text-center border-b border-gray-50 relative">
                            <button onClick={() => setIsContactOpen(false)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition">
                                <X size={20} />
                            </button>
                            <h3 className="text-xl font-black text-gray-800">Contacto</h3>
                            <p className="text-xs text-gray-400 font-medium">¿En qué podemos ayudarte?</p>
                        </div>
                        <div className="p-4 space-y-3">
                            {config.contact?.whatsapp && (
                                <a href={`https://wa.me/${config.contact.whatsapp.replace(/\D/g, '')}`} target="_blank" rel="noreferrer" className="flex items-center gap-4 p-3 rounded-2xl bg-green-50 text-green-700 hover:bg-green-100 transition border border-green-100">
                                    <img src="https://cdn.simpleicons.org/whatsapp" alt="" className="w-8 h-8" />
                                    <div className="text-left">
                                        <p className="text-[10px] font-black uppercase opacity-60 leading-none mb-1">WhatsApp</p>
                                        <p className="font-bold">{config.contact.whatsapp}</p>
                                    </div>
                                </a>
                            )}
                            <div className="grid grid-cols-2 gap-3">
                                {config.contact?.instagram && (
                                    <a href={config.contact.instagram.startsWith('http') ? config.contact.instagram : `https://instagram.com/${config.contact.instagram.replace('@', '')}`} target="_blank" rel="noreferrer" className="flex flex-col items-center justify-center p-3 rounded-2xl bg-pink-50 text-pink-700 hover:bg-pink-100 transition border border-pink-100">
                                        <img src="https://cdn.simpleicons.org/instagram" alt="" className="w-6 h-6 mb-1" />
                                        <span className="text-[10px] font-bold">Instagram</span>
                                    </a>
                                )}
                                {config.contact?.facebook && (
                                    <a href={config.contact.facebook.startsWith('http') ? config.contact.facebook : `https://facebook.com/${config.contact.facebook}`} target="_blank" rel="noreferrer" className="flex flex-col items-center justify-center p-3 rounded-2xl bg-blue-50 text-blue-700 hover:bg-blue-100 transition border border-blue-100">
                                        <img src="https://cdn.simpleicons.org/facebook" alt="" className="w-6 h-6 mb-1" />
                                        <span className="text-[10px] font-bold">Facebook</span>
                                    </a>
                                )}
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                                {config.contact?.website && (
                                    <a href={config.contact.website} target="_blank" rel="noreferrer" className="flex flex-col items-center justify-center p-3 rounded-2xl bg-gray-50 text-gray-700 hover:bg-gray-100 transition border border-gray-100">
                                        <span className="text-xl mb-1">🌐</span>
                                        <span className="text-[10px] font-bold">Sitio Web</span>
                                    </a>
                                )}
                                {config.contact?.email && (
                                    <a href={`mailto:${config.contact.email}`} className="flex flex-col items-center justify-center p-3 rounded-2xl bg-gray-50 text-gray-700 hover:bg-gray-100 transition border border-gray-100">
                                        <span className="text-xl mb-1">✉️</span>
                                        <span className="text-[10px] font-bold">Correo</span>
                                    </a>
                                )}
                            </div>
                        </div>
                        <div className="p-4 pt-0 text-center space-y-4">
                            {config.contact?.termsAndConditions && (
                                <a href={config.contact.termsAndConditions} target="_blank" rel="noreferrer" className="block text-[10px] text-gray-400 underline font-medium hover:text-gray-600">
                                    Ver Términos y Condiciones
                                </a>
                            )}
                            <button onClick={() => setIsContactOpen(false)}
                                className="w-full py-3.5 rounded-2xl text-white font-bold text-sm shadow-lg active:scale-95 transition"
                                style={{ backgroundColor: 'var(--primary, #111827)' }}
                            >
                                Entendido
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};
