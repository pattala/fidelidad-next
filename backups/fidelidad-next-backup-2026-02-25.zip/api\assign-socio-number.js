
// api/assign-socio-number.js
// Asigna número de socio correlativo y envía email (opcional).
// Refactorizado para consistencia con create-user.js (CORS robusto, Auth check, Safe Parsing).

import admin from "firebase-admin";

// ---------- Firebase Admin ----------
function initFirebaseAdmin() {
  if (admin.apps.length) return;

  const raw = process.env.GOOGLE_CREDENTIALS_JSON;
  if (!raw) throw new Error("GOOGLE_CREDENTIALS_JSON missing");

  let sa;
  try { sa = JSON.parse(raw); }
  catch { throw new Error("Invalid GOOGLE_CREDENTIALS_JSON (not valid JSON)"); }

  admin.initializeApp({
    credential: admin.credential.cert(sa),
  });
}

function getDb() {
  initFirebaseAdmin();
  return admin.firestore();
}

// ---------- CORS ----------
function getAllowedOrigin(req) {
  // Configuración más permisiva por defecto para evitar errores CORS en setups nuevos
  const envAllowed = process.env.CORS_ALLOWED_ORIGINS;

  // Si no hay variable definida, permitimos el origen de la petición (modo desarrollo/demo)
  if (!envAllowed) return req.headers.origin || "*";

  const allowed = envAllowed.split(",").map(s => s.trim()).filter(Boolean);
  const origin = req.headers.origin;

  if (origin && allowed.includes(origin)) return origin;
  return allowed[0] || "";
}

function setCors(res, origin) {
  if (origin) res.setHeader("Access-Control-Allow-Origin", origin);
  res.setHeader("Vary", "Origin");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS, GET");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, x-api-key, Authorization");
}

// ---------- Body seguro ----------
async function readJsonBody(req) {
  // En Vercel a veces req.body ya viene parseado si usas ciertos middleware,
  // pero para standard raw function:
  if (req.body && typeof req.body === 'object') return req.body;
  if (req.body && typeof req.body === 'string') {
    try { return JSON.parse(req.body); } catch { throw new Error("BAD_JSON"); }
  }
  // Fallback stream reading (raro en Vercel Functions modernas pero util)
  try {
    const chunks = [];
    for await (const c of req) chunks.push(c);
    const raw = Buffer.concat(chunks).toString("utf8");
    if (!raw) return {};
    return JSON.parse(raw);
  } catch {
    const e = new Error("BAD_JSON");
    e.code = "BAD_JSON";
    throw e;
  }
}

// ---------- Config Email ----------
// URL para llamarse a sí mismo (email)
function getSelfBaseUrl(req) {
  if (process.env.PUBLIC_BASE_URL) return process.env.PUBLIC_BASE_URL;
  const host = req.headers.host;
  const proto = req.headers['x-forwarded-proto'] || 'https';
  return `${proto}://${host}`;
}

// ---------- Handler ----------
export default async function handler(req, res) {
  initFirebaseAdmin(); // Ensure admin is initialized for all subsequent calls
  const allowOrigin = getAllowedOrigin(req);
  setCors(res, allowOrigin);

  if (req.method === "OPTIONS") return res.status(204).end();

  if (req.method !== "POST") {
    return res.status(405).json({ ok: false, error: "Method Not Allowed" });
  }

  // API key Check (Seguridad)
  const clientKey = req.headers["x-api-key"];
  const authHeader = req.headers["authorization"];
  let isAuthorized = false;

  // Option 1: API Key
  if (process.env.API_SECRET_KEY && clientKey === process.env.API_SECRET_KEY) {
    isAuthorized = true;
  }

  // Body Parsing (needed for docId check in Token Auth)
  let payload = {};
  try { payload = await readJsonBody(req); }
  catch (e) { return res.status(400).json({ ok: false, error: "Invalid JSON body" }); }

  const { docId, sendWelcome } = payload;
  if (!docId) return res.status(400).json({ ok: false, error: "Falta docId" });

  // Option 2: Firebase Token Auth (Self-assignment or Admin)
  if (!isAuthorized && authHeader && authHeader.startsWith("Bearer ")) {
    try {
      const token = authHeader.split("Bearer ")[1];
      const decodedToken = await admin.auth().verifyIdToken(token);

      // If user is assigning to themselves OR is a master/admin
      if (decodedToken.uid === docId) {
        isAuthorized = true;
      } else {
        // Use environment variable for Master Admins in API
        const masterAdmins = (process.env.MASTER_ADMINS || "pablo_attala@yahoo.com.ar").split(",").map(e => e.trim().toLowerCase());
        if (masterAdmins.includes(decodedToken.email?.toLowerCase())) {
          isAuthorized = true;
        }
      }
    } catch (err) {
      console.warn("Invalid token in assign-socio-number:", err.message);
    }
  }

  if (!isAuthorized && process.env.API_SECRET_KEY) {
    console.warn("Unauthorized attempt to assign-socio-number. docId:", docId);
    return res.status(401).json({ ok: false, error: "Unauthorized" });
  }

  // Lógica de negocio
  try {
    const db = getDb();
    const contadorRef = db.collection('config').doc('counters');
    const clienteRef = db.collection("users").doc(docId);

    let datosClienteParaEmail = null;
    let assignedNumber = null;
    let alreadyHadNumber = false;

    await db.runTransaction(async (tx) => {
      const [contadorDoc, clienteDoc] = await Promise.all([
        tx.get(contadorRef),
        tx.get(clienteRef),
      ]);

      if (!clienteDoc.exists) throw new Error("Cliente no encontrado");

      const data = clienteDoc.data();
      if (data.numeroSocio || data.socioNumber) {
        alreadyHadNumber = true;
        assignedNumber = data.numeroSocio || data.socioNumber;
        return;
      }

      // Calcular nuevo número
      let nextNum = 1000;
      if (contadorDoc.exists && contadorDoc.data().lastSocioId) {
        nextNum = Number(contadorDoc.data().lastSocioId) + 1;
      }

      // Escribir
      tx.set(contadorRef, { lastSocioId: nextNum }, { merge: true });
      tx.update(clienteRef, {
        socioNumber: nextNum,
        numeroSocio: nextNum
      });

      assignedNumber = nextNum;
      datosClienteParaEmail = {
        id_cliente: docId,
        nombre: data.nombre,
        email: data.email,
        puntos_ganados: data.puntos || 0,
        numero_socio: nextNum
      };
    });

    if (alreadyHadNumber) {
      return res.status(200).json({
        ok: true,
        numeroSocio: assignedNumber,
        message: "El cliente ya tenía número de socio.",
        emailEnviado: false
      });
    }

    // Enviar email si corresponde
    let mailResult = null;
    if (sendWelcome && datosClienteParaEmail) {
      try {
        const baseUrl = getSelfBaseUrl(req);
        console.log(`[AssignSocio] Intentando enviar email. URL: ${baseUrl}/api/send-email`);

        const SECRET = process.env.API_SECRET_KEY || process.env.VITE_API_KEY;

        // Llamada interna a la API de email
        const startTime = Date.now();
        const r = await fetch(`${baseUrl}/api/send-email`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': SECRET || ''
          },
          body: JSON.stringify({
            to: datosClienteParaEmail.email,
            templateId: 'bienvenida',
            templateData: {
              nombre: datosClienteParaEmail.nombre,
              numero_socio: datosClienteParaEmail.numero_socio,
              puntos_ganados: datosClienteParaEmail.puntos_ganados,
              id_cliente: datosClienteParaEmail.id_cliente
            }
          })
        });

        const status = r.status;
        const text = await r.text();
        const duration = Date.now() - startTime;
        console.log(`[AssignSocio] Respuesta email (${status}) en ${duration}ms:`, text.slice(0, 200));

        try {
          mailResult = JSON.parse(text);
        } catch {
          mailResult = { error: "Non-JSON response from send-email", body: text.slice(0, 100) };
        }

      } catch (errEmail) {
        console.error("Error enviando email welcome:", errEmail);
        mailResult = { error: "Failed to send email", details: errEmail.message };
      }
    } else {
      console.log('[AssignSocio] Skipping email. sendWelcome=', sendWelcome, ' datos=', !!datosClienteParaEmail);
    }

    // --- AUDITORIA ---
    try {
      let executor = 'admin';
      if (authHeader && authHeader.startsWith("Bearer ")) {
        const token = authHeader.split("Bearer ")[1];
        const decoded = await admin.auth().verifyIdToken(token);
        executor = decoded.email || decoded.uid || 'admin';
      }

      await db.collection('audit_logs').add({
        timestamp: admin.firestore.FieldValue.serverTimestamp(),
        type: 'user_mgmt',
        status: 'success',
        summary: `Asignación de #Socio: ${datosClienteParaEmail?.nombre || 'Socio'} (#${assignedNumber})`,
        details: [
          { action: 'socio_number_assigned', status: 'success', info: `ID: ${docId}, #Socio: ${assignedNumber}` },
          { action: 'email_welcome', status: sendWelcome ? (mailResult?.ok ? 'success' : 'failed') : 'skipped', info: sendWelcome ? `Resultado: ${JSON.stringify(mailResult)}` : 'No solicitado' }
        ],
        executor
      });
    } catch (auditErr) {
      console.error("Audit error in assign-socio-number:", auditErr);
    }

    return res.status(200).json({
      ok: true,
      numeroSocio: assignedNumber,
      emailEnviado: !!(sendWelcome && datosClienteParaEmail),
      mail: mailResult
    });

  } catch (error) {
    console.error("assign-socio-number error:", error);
    return res.status(500).json({ ok: false, error: error.message });
  }
}
