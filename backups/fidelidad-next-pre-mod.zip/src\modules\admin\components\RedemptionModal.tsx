import { useState, useEffect } from 'react';
import { X, Gift, CheckCircle } from 'lucide-react';
import { PrizeService } from '../../../services/prizeService';
import type { Prize } from '../../../types';
import { collection, addDoc, updateDoc, doc, increment, arrayUnion } from 'firebase/firestore';
import { db } from '../../../lib/firebase';
import { NotificationService } from '../../../services/notificationService';
import toast from 'react-hot-toast';

interface RedemptionModalProps {
    client: any; // Se puede mejorar la interfaz Client
    onClose: () => void;
    onRedeemSuccess: () => void;
}

export const RedemptionModal = ({ client, onClose, onRedeemSuccess }: RedemptionModalProps) => {
    const [prizes, setPrizes] = useState<Prize[]>([]);
    const [selectedPrize, setSelectedPrize] = useState<Prize | null>(null);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        const loadPrizes = async () => {
            const allPrizes = await PrizeService.getActive();
            // Filtrar disponibilidad básica (los que alcanzan y tienen stock)
            // Se puede mostrar todos y deshabilitar los que no alcanzan para "incentivar"
            setPrizes(allPrizes);
        };
        loadPrizes();
    }, []);

    const handleRedeem = async () => {
        if (!selectedPrize) return;
        if (client.points < selectedPrize.pointsRequired) {
            toast.error("Puntos insuficientes");
            return;
        }
        if (selectedPrize.stock <= 0) {
            toast.error("No hay stock disponible");
            return;
        }

        if (!confirm(`¿Confirmar canje de ${selectedPrize.name} por ${selectedPrize.pointsRequired} pts?`)) return;

        setLoading(true);
        try {
            // 1. Registrar Canje en Historial (Débito) - Subcollection
            const cleanClientId = client.id.trim();
            if (!cleanClientId) {
                throw new Error("ID de cliente inválido");
            }

            console.log("Procesando canje para cliente:", cleanClientId);

            await addDoc(collection(db, `users/${cleanClientId}/points_history`), { // Changed 'users' to 'clientes'
                amount: -selectedPrize.pointsRequired, // Negativo
                concept: `Canje: ${selectedPrize.name}`,
                date: new Date(),
                type: 'debit',
                prizeId: selectedPrize.id,
                redeemedValue: selectedPrize.cashValue || 0
            });

            // 2. Descontar Puntos al cliente y Actualizar Array (PWA)
            const userRef = doc(db, 'users', cleanClientId); // Changed 'users' to 'clientes'
            await updateDoc(userRef, {
                points: increment(-selectedPrize.pointsRequired),
                historialCanjes: arrayUnion({
                    fechaCanje: new Date(),
                    nombrePremio: selectedPrize.name,
                    puntosCoste: selectedPrize.pointsRequired,
                    prizeId: selectedPrize.id
                })
            });

            // 3. Descontar Stock del premio
            await PrizeService.update(selectedPrize.id, {
                stock: increment(-1) as any // Cast simple
            });

            // 4. Notificaciones Granulares
            try {
                // Import dinámico de ConfigService para evitar ciclos, o usar el que ya tenemos si se refactoriza.
                // Usando import dinámico como estaba:
                const { ConfigService, DEFAULT_TEMPLATES } = await import('../../../services/configService');
                const config = await ConfigService.get();

                // 4.1 WhatsApp
                if (NotificationService.isChannelEnabled(config, 'redemption', 'whatsapp') && client.phone) {
                    const phone = client.phone.replace(/\D/g, '');
                    if (phone) {
                        const template = config?.messaging?.templates?.redemption || DEFAULT_TEMPLATES.redemption;
                        const msg = template
                            .replace(/{nombre}/g, client.name.split(' ')[0])
                            .replace(/{nombre_completo}/g, client.name)
                            .replace(/{premio}/g, selectedPrize.name)
                            .replace(/{codigo}/g, selectedPrize.id.substring(0, 4).toUpperCase())
                            .replace(/{dni}/g, client.dni || '')
                            .replace(/{email}/g, client.email || '');

                        window.open(`https://wa.me/${phone}?text=${encodeURIComponent(msg)}`, '_blank');
                    }
                }

                // 4.2 Push
                if (NotificationService.isChannelEnabled(config, 'redemption', 'push')) {
                    const template = config?.messaging?.templates?.redemption || DEFAULT_TEMPLATES.redemption;
                    const msg = template
                        .replace(/{nombre}/g, client.name.split(' ')[0])
                        .replace(/{nombre_completo}/g, client.name)
                        .replace(/{premio}/g, selectedPrize.name)
                        .replace(/{codigo}/g, selectedPrize.id.substring(0, 4).toUpperCase())
                        .replace(/{dni}/g, client.dni || '')
                        .replace(/{email}/g, client.email || '');

                    await NotificationService.sendToClient(cleanClientId, {
                        title: '¡Canje Exitoso!',
                        body: msg,
                        type: 'redemption',
                        icon: config?.logoUrl // Branding
                    });
                }

            } catch (e) {
                console.error("Error enviando notificaciones canje:", e);
            }

            toast.success("¡Canje realizado con éxito!");
            onRedeemSuccess();
            onClose();
        } catch (error) {
            console.error(error);
            toast.error("Error al procesar canje");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
            <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden animate-scale-up flex flex-col max-h-[90vh]">

                {/* Header */}
                <div className="bg-gradient-to-r from-pink-500 to-rose-600 px-6 py-4 flex justify-between items-center shrink-0">
                    <div>
                        <h2 className="text-xl font-bold text-white flex items-center gap-2">
                            <Gift size={24} /> Canjear Puntos
                        </h2>
                        <p className="text-pink-100 text-sm opacity-90">
                            Cliente: <span className="font-bold">{client.name}</span> | Saldo: <span className="font-bold bg-white/20 px-2 py-0.5 rounded text-white">{client.points} pts</span>
                        </p>
                    </div>
                    <button onClick={onClose} className="text-white/80 hover:text-white hover:bg-white/20 rounded-full p-2 transition">
                        <X size={24} />
                    </button>
                </div>

                {/* Body - Grid de Premios */}
                <div className="p-6 overflow-y-auto bg-gray-50 flex-1">
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                        {prizes.map(prize => {
                            const canAfford = client.points >= prize.pointsRequired;
                            const hasStock = prize.stock > 0;
                            const isSelected = selectedPrize?.id === prize.id;

                            return (
                                <div
                                    key={prize.id}
                                    onClick={() => (canAfford && hasStock) && setSelectedPrize(prize)}
                                    className={`
                                        relative rounded-xl border-2 p-4 cursor-pointer transition-all flex flex-col justify-between min-h-[160px]
                                        ${isSelected ? 'border-pink-500 bg-pink-50 ring-2 ring-pink-200' : 'bg-white border-gray-200 hover:border-pink-300'}
                                        ${(!canAfford || !hasStock) ? 'opacity-50 grayscale cursor-not-allowed' : ''}
                                    `}
                                >
                                    {/* Badge Estado */}
                                    <div className="absolute top-2 right-2">
                                        {!hasStock && <span className="bg-red-100 text-red-600 text-[10px] font-bold px-2 py-1 rounded">SIN STOCK</span>}
                                        {!canAfford && hasStock && <span className="bg-gray-100 text-gray-500 text-[10px] font-bold px-2 py-1 rounded">FALTAN PTOS</span>}
                                    </div>

                                    <div className="mb-2">
                                        <h3 className="font-bold text-gray-800 leading-tight">{prize.name}</h3>
                                        <p className="text-[10px] text-gray-400 mt-1 line-clamp-2">{prize.description}</p>
                                    </div>

                                    <div className="mt-auto pt-2 border-t border-gray-100 flex justify-between items-center">
                                        <span className={`font-black text-lg ${canAfford ? 'text-pink-600' : 'text-gray-400'}`}>
                                            {prize.pointsRequired} <span className="text-xs">pts</span>
                                        </span>
                                        {isSelected && <CheckCircle className="text-pink-500" size={20} />}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>

                {/* Footer */}
                <div className="p-4 bg-white border-t border-gray-100 shrink-0 flex justify-end gap-3">
                    <button onClick={onClose} className="px-6 py-3 text-gray-500 font-medium hover:bg-gray-50 rounded-xl">
                        Cancelar
                    </button>
                    <button
                        onClick={handleRedeem}
                        disabled={!selectedPrize || loading}
                        className={`
                            px-8 py-3 rounded-xl font-bold text-white shadow-lg flex items-center gap-2 transition-all
                            ${!selectedPrize ? 'bg-gray-300 cursor-not-allowed' : 'bg-pink-600 hover:bg-pink-700 active:scale-95 shadow-pink-200'}
                        `}
                    >
                        {loading ? 'Procesando...' : 'Confirmar Canje'}
                    </button>
                </div>
            </div>
        </div>
    );
};
